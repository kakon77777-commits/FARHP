# FARHP 系列 v0.6

本封裝包含「基頻錨定相對諧波相位差」第一至第六篇論文、兩層交換規格，以及 `FARHP-Core v0.2` 可執行研究原型。

## 推進狀態

$$
4\text{ 篇理論基礎}
\rightarrow
1\text{ 篇單框架工程}
\rightarrow
1\text{ 篇軌跡工程}
\rightarrow
\boxed{\text{目前位置}}
$$

下一篇將進入相位控制、音色變換與新音生成。

## 快速開始

```bash
cd farhp_core_v0.2
python -m pip install -e .
farhp demo-track --out artifacts/trajectory_demo
python -m unittest discover -s tests -v
```

## 重要邊界

- 動態基準來自合成母音，不是自然語音資料集；
- 重建目前只包含諧波部分；
- `FARHP-G` 聲門域仍需逆濾波與外部驗證；
- 所有知覺與自然語音結論仍待實驗。
