"""FARHP-Core v0.2: trajectory-aware fundamental-anchored relative harmonic phase."""

from .analyzer import AnalysisConfig, analyze_frame, analyze_waveform, estimate_f0_yin
from .codebook import TorusCodebook
from .model import FARHPFrame, FARHPTrajectory
from .quantizer import CircularScalarQuantizer
from .reconstructor import reconstruct_frame, reconstruct_trajectory
from .synth import VOWEL_FORMANTS, dynamic_synthetic_vowel, harmonic_synthesize, synthetic_vowel
from .tracking import TrackingConfig, analyze_trajectory, estimate_f0_candidates, track_f0_viterbi
from .utils import circular_distance, torus_distance, wrap_phase

__all__ = [
    "AnalysisConfig",
    "CircularScalarQuantizer",
    "FARHPFrame",
    "FARHPTrajectory",
    "TorusCodebook",
    "TrackingConfig",
    "VOWEL_FORMANTS",
    "analyze_frame",
    "analyze_trajectory",
    "analyze_waveform",
    "circular_distance",
    "dynamic_synthetic_vowel",
    "estimate_f0_candidates",
    "estimate_f0_yin",
    "harmonic_synthesize",
    "reconstruct_frame",
    "reconstruct_trajectory",
    "synthetic_vowel",
    "torus_distance",
    "track_f0_viterbi",
    "wrap_phase",
]

__version__ = "0.2.0"
