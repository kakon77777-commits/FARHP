# EMPSL v0.1 驗證報告

- 日期：2026-07-31
- JSON Schema：Draft 2020-12
- NFC 檢查：PASS
- 字形配方 SHA-256：PASS
- `EMPSL_seed_lexicon_v0.1.json`：PASS
- `EMPSL_expression_example_v0.1.json`：PASS
- 詞彙／算子項目：3
- 表達式：1
- 以諾式歷史靈感種子 ID：21
- 現代結構種子 ID：11
- 相位可視碼：16
- 語義類：16
- 算子附標：16

## 規範文件雜湊

`document_sha256=ea90d16bb2780b5e3f9d27271bc94c83cc0490004b1e2d67c77afb57dd78f4c2`

`document_sha256=9478fa5dc41c1e82e8fdf5879d90f1b6f0b8aa486dec761434ff4fb36e2d5a8e`

本驗證只證明交換格式、NFC、字形配方雜湊與範例符合 v0.1 規格，不證明字形可辨識度、自然語音品質或語義本體完整性。
