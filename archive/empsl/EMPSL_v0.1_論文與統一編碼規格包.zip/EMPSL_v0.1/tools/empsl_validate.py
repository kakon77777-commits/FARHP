#!/usr/bin/env python3
"""Validate and hash EMPSL v0.1 documents."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import unicodedata
from pathlib import Path

from jsonschema import Draft202012Validator


def canonical_json(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def walk_strings(value: object, path: str = "$"):
    if isinstance(value, str):
        yield path, value
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from walk_strings(item, f"{path}[{index}]")
    elif isinstance(value, dict):
        for key, item in value.items():
            yield from walk_strings(item, f"{path}.{key}")


def validate_document(document_path: Path, schema_path: Path) -> tuple[bool, list[str], str]:
    doc = json.loads(document_path.read_text(encoding="utf-8"))
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    errors: list[str] = []

    validator = Draft202012Validator(schema)
    for error in sorted(validator.iter_errors(doc), key=lambda e: list(e.absolute_path)):
        location = "$" + "".join(f"[{part!r}]" for part in error.absolute_path)
        errors.append(f"schema {location}: {error.message}")

    for location, text in walk_strings(doc):
        if unicodedata.normalize("NFC", text) != text:
            errors.append(f"normalization {location}: string is not NFC")

    for index, entry in enumerate(doc.get("entries", [])):
        recipe = dict(entry["glyph_recipe"])
        stored = recipe.get("recipe_hash")
        recipe["recipe_hash"] = None
        expected = hashlib.sha256(canonical_json(recipe)).hexdigest()
        if stored != expected:
            errors.append(
                f"recipe_hash $.entries[{index}]: expected {expected}, got {stored}"
            )

    digest = hashlib.sha256(canonical_json(doc)).hexdigest()
    return not errors, errors, digest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("document", type=Path)
    parser.add_argument(
        "--schema",
        type=Path,
        default=Path(__file__).resolve().parents[1]
        / "spec"
        / "EMPSL_Unified_Encoding_Spec_v0.1.schema.json",
    )
    args = parser.parse_args()

    try:
        ok, errors, digest = validate_document(args.document, args.schema)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    if not ok:
        for error in errors:
            print(f"FAIL: {error}", file=sys.stderr)
        return 1

    print("PASS")
    print(f"document_sha256={digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
