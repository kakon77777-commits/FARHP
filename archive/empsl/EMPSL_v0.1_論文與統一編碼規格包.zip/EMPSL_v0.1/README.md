# EMPSL v0.1 交付包

本包是「以諾—華語相位符號語言」的第一份母規格，不含正式字型檔。

## 內容

- `FARHP_09_以諾華語相位符號語言_統一編碼_v0.1.md`：第九篇論文；
- `spec/EMPSL_Spec_v0.1.yaml`：人類可讀規格；
- `spec/EMPSL_Unified_Encoding_Spec_v0.1.schema.json`：交換物件 Schema；
- `examples/EMPSL_seed_lexicon_v0.1.json`：三個初始詞彙／算子；
- `examples/EMPSL_expression_example_v0.1.json`：因果 AST 範例；
- `FARHP_系列索引_v0.8_語言整合橋接.md`：系列狀態；
- `SHA256SUMS.txt`：完整性清單。

## 已驗證

兩份範例 JSON 已使用 Draft 2020-12 JSON Schema 驗證通過。

## 重要邊界

- 歷史以諾字形只作視覺靈感，不宣稱歷史復原；
- PUA 只作顯示別名，不是符號身份；
- EMPSL 不是加密系統；
- 正式字型與 32 個 SVG 種子尚未製作。

## 驗證器

```bash
python -m pip install -r requirements.txt
python tools/empsl_validate.py examples/EMPSL_seed_lexicon_v0.1.json
python tools/empsl_validate.py examples/EMPSL_expression_example_v0.1.json
```
