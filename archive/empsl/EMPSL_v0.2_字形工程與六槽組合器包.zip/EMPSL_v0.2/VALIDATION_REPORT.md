# EMPSL v0.2 驗證報告

**日期：** 2026-07-31  
**結果：** 18/18 PASS

## 測試明細

| 項目 | 結果 | 細節 |
|---|---:|---|
| atom count | PASS | 128 |
| unique atom IDs | PASS |  |
| category counts | PASS | {'seed': 32, 'semantic_frame': 16, 'phase_mark': 16, 'operator_mark': 16, 'phonology_tone_structure': 48} |
| 128 SVG XML parse | PASS | [] |
| atom registry JSON Schema | PASS |  |
| sample recipe JSON Schema | PASS | 3 recipes |
| exact raster collisions | PASS | [] |
| JS syntax assets/empsl_core.js | PASS |  |
| JS syntax assets/app.js | PASS |  |
| JS syntax data/EMPSL_atom_registry_v0.2.js | PASS |  |
| Node core tests | PASS | PASS EMPSL core tests · 6 groups |
| Python recipe validator | PASS | PASS recipes=3 atoms=128 |
| HTML asset data/EMPSL_atom_registry_v0.2.js | PASS |  |
| HTML asset assets/empsl_core.js | PASS |  |
| HTML asset assets/app.js | PASS |  |
| chart assets/charts/EMPSL_128_atom_chart_v0.2.png | PASS | 398906 |
| chart assets/charts/EMPSL_32_seed_chart_v0.2.png | PASS | 137661 |
| chart assets/charts/EMPSL_six_slot_example_v0.2.png | PASS | 85355 |

## 碰撞診斷

- 完全相同的 64×64 正規化像素碰撞：0 組。
- 最近鄰距離只是工程診斷；同一功能族的幾何近似仍須在後續做人類辨識測試。

## 瀏覽器測試說明

- `index.html`、三份 JavaScript 資產及匯出核心已通過語法、引用與 Node 功能測試。
- 本執行環境的 Chromium headless 即使載入 `about:blank` 也無法正常退出，因此本輪未宣稱完成 Chromium 端到端互動測試。
- 預覽 PNG 由與網站相同的 SVG 原子註冊表透過 CairoSVG 生成。

## 判定

v0.2 已達成字形工程 MVP：128 原子可解析、六槽配方可驗證、雜湊可往返、圖表可輸出，且沒有完全相同的原子像素碰撞。OpenType、輸入法與人類可辨識度仍屬下一階段。
