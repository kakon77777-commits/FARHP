(function(root,factory){if(typeof module==='object'&&module.exports){module.exports=factory();}else{root.EMPSLCore=factory();}})(typeof self!=='undefined'?self:this,function(){
  function canonicalRecipe(recipe){
    const core={frame:recipe.frame,seed:recipe.seed,phonology:[...(recipe.phonology||[])],tone:recipe.tone,phase:recipe.phase,operator:recipe.operator};
    return JSON.stringify(core,Object.keys(core).sort());
  }
  function fnv32x8(text){let out='';for(let lane=0;lane<8;lane++){let h=(0x811c9dc5^lane)>>>0;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,0x01000193)>>>0;}out+=h.toString(16).padStart(8,'0');}return out;}
  async function recipeHash(recipe){const txt=canonicalRecipe(recipe);if(globalThis.crypto&&crypto.subtle){const buf=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(txt));return [...new Uint8Array(buf)].map(x=>x.toString(16).padStart(2,'0')).join('');}return fnv32x8(txt);}
  function mapAtoms(reg){return Object.fromEntries(reg.atoms.map(a=>[a.id,a]));}
  function composeSvg(recipe,registry){const m=mapAtoms(registry);const b=id=>m[id]?m[id].body:'';const g=(body,t)=>`<g transform="${t}">${body}</g>`;let p=[`<rect width="512" height="512" rx="36" fill="#fbf6ea"/>`,g(b(recipe.frame),'scale(2)'),g(b(recipe.seed),'translate(112 112) scale(1.125)')];const pos=[[38,292],[38,360],[106,360]];(recipe.phonology||[]).slice(0,4).forEach((id,i)=>p.push(g(b(id),`translate(${pos[i][0]} ${pos[i][1]}) scale(0.32)`)));p.push(g(b(recipe.tone),'translate(192 18) scale(0.5)'));p.push(g(b(recipe.phase),'translate(360 48) scale(0.42)'));p.push(g(b(recipe.operator),'translate(354 352) scale(0.45)'));return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">${p.join('')}</svg>`;}
  function validateRecipe(recipe,registry,profiles){const ids=new Set(registry.atoms.map(a=>a.id));const errors=[];for(const k of ['frame','seed','tone','phase','operator'])if(!ids.has(recipe[k]))errors.push(`unknown ${k}: ${recipe[k]}`);for(const p of recipe.phonology||[])if(!ids.has(p))errors.push(`unknown phonology: ${p}`);if((recipe.phonology||[]).length>4)errors.push('phonology has more than 4 marks in v0.2');return {ok:errors.length===0,errors};}
  return {canonicalRecipe,recipeHash,composeSvg,validateRecipe};
});
