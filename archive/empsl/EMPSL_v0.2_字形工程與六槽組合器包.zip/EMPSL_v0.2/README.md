# EMPSL Glyph Forge v0.2

本包將 EMPSL v0.1 母規格推進為字形工程 MVP。

## 直接使用

開啟 `index.html`。所有資料均內嵌／本地載入，不需要伺服器。

## 內容

- `assets/atoms/`：128 個獨立 SVG 原子；
- `assets/charts/`：32 種子、128 原子與六槽示範圖；
- `data/`：原子註冊表、組合剖面、範例配方、碰撞報告；
- `spec/`：YAML 與 JSON Schema；
- `tools/empsl_glyph_validate.py`：配方驗證器；
- `tests/test_core.js`：Node 核心測試；
- `index.html`：互動六槽字形組合器。

## 驗證

```bash
python -m pip install jsonschema cairosvg pillow
python tools/empsl_glyph_validate.py data/EMPSL_sample_recipes_v0.2.json
node tests/test_core.js
```

## 重要邊界

SVG 與未來 PUA／OpenType 都是顯示層。穩定 ID、六槽配方、概念 ID 與 FARHP 精確資料才是可交換本體。本系統不是加密工具。
