# EMPSL v0.3 — 受控字形變換與碰撞驗證層

EMPSL v0.3 在 v0.2 的 32 個核心種子與六槽組合器上，加入 8 種受控變換，形成 256 個可追溯種子變體，並以 8,192 個複合字形進行 exact／near collision 測試。

## 快速使用

直接開啟 `index.html`，或：

```bash
python -m http.server 8000
```

驗證：

```bash
python tools/empsl_v03_validate.py
node tests/test_core_v0.3.js
```

## 身份雙軌

- `raw_body`：純幾何變換，用於研究對稱性和碰撞。
- `body`：規範變體，加入 3-bit 變換見證，作為可逆顯示層。
- 規範資料身份仍由配方 JSON 與 SHA-256 決定。

## 8 種變換

- `ID`：原形 — 保持基礎種子幾何。
- `R90`：順時針旋轉 90° — 繞字形中心旋轉 90°。
- `R180`：旋轉 180° — 繞字形中心旋轉 180°。
- `MX`：水平鏡像 — 沿垂直中軸左右鏡像。
- `OPEN-R`：右側開口 — 以可逆遮罩移除右側中段，形成開口。
- `CLOSED`：外圈閉合 — 加上外部閉合環，標示封閉變體。
- `INSET`：菱框內嵌 — 縮放基礎種子並嵌入菱形框。
- `CROSS`：交叉覆合 — 疊加對角交叉骨架。

## 大規模碰撞測試

- 樣本：8,192 個唯一六槽配方。
- exact：64×64 灰階像素 SHA-256。
- near：64-bit dHash，Hamming 距離不大於 4。
- near collision 是人工審查候選，不是語義碰撞的證明。
