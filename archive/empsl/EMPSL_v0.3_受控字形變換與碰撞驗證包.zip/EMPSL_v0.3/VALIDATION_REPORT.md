# EMPSL v0.3 驗證報告

## 摘要

- 核心種子：32
- 受控變換：8
- 規範種子變體：256
- 純幾何 exact collision groups：40
- 規範變體 exact collision groups：0
- 複合碰撞樣本：8,192
- 複合 exact collision groups：0
- 記錄的 near-collision 候選：400

## 身份結果

純幾何層允許因對稱性產生碰撞；規範層加入三位元見證。本批次規範變體的正規化 64×64 像素 exact collision groups 為 **0**。

## 複合測試

8,192 個配方均具有唯一配方 SHA-256。像素碰撞與配方碰撞分開處理：即使兩個字形低解析度相似，穩定身份仍不會被合併。

## 自動驗證

執行：

```bash
python tools/empsl_v03_validate.py
node tests/test_core_v0.3.js
```

最終命令輸出將在封裝前重新寫入本報告。
