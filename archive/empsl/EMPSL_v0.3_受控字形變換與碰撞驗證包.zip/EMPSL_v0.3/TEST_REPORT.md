# EMPSL v0.3 測試報告

## 結論

EMPSL v0.3 的資料規格、SVG 變體、六槽組合、碰撞語料、JavaScript 核心與瀏覽器互動均通過本輪驗證。

## 自動驗證

```text
Python validator: 21 / 21 PASS
Node core tests: 14 groups PASS
JavaScript syntax: PASS
JSON / YAML parsing: PASS
Playwright Chromium interaction: PASS
Console errors: 0
```

## 變體層

| 指標 | 結果 |
|---|---:|
| 基礎種子 | 32 |
| 受控變換 | 8 |
| 純幾何變體 | 256 |
| 規範見證變體 | 256 |
| 解析成功的 SVG | 512 / 512 |
| 純幾何 exact collision groups | 40 |
| 涉及純幾何變體 | 104 |
| 規範變體 exact collision groups | 0 |

純幾何碰撞是預期的診斷結果，主要來自旋轉／鏡像對稱與開口遮罩後的輪廓退化。規範變體加入三位元變換見證後，本批次 64×64 正規化像素完全碰撞為 0。

## 複合字形層

| 指標 | 結果 |
|---|---:|
| 唯一配方 | 8,192 |
| 配方 SHA-256 唯一 | 8,192 / 8,192 |
| 64×64 像素 exact collision groups | 0 |
| dHash 近碰撞門檻 | Hamming ≤ 4 |
| 保存的近碰撞候選 | 400（上限截斷） |

近碰撞只表示低解析度輪廓候選，不等於語義或可讀性碰撞。規範身份仍由結構化配方與 SHA-256 決定。

## 瀏覽器互動

Chromium 實際完成：

- 初始配方驗證；
- `ENO-07@OPEN-R` 規範變體顯示；
- 切換至 `CROSS`；
- 切換純幾何模式；
- 依基礎種子顯示 8 個變體；
- 依變換顯示 32 個種子；
- 更新配方雜湊；
- 生成完整頁面截圖。

執行環境會以管理政策封鎖本機 HTTP 與 `file://` 導航，因此瀏覽器測試將所有本地 JavaScript／JSON 資產內嵌至測試頁面。這驗證了實際 DOM 與互動邏輯，但不是公開網路部署測試。
