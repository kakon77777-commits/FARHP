from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[1]

@dataclass(frozen=True)
class Settings:
    database_url: str = os.getenv("FARHP_DATABASE_URL", f"sqlite:///{ROOT / 'data' / 'farhp_v09.sqlite3'}")
    secret_key: str = os.getenv("FARHP_SECRET_KEY", "farhp-v0.9-demo-secret-change-me")
    token_max_age_seconds: int = int(os.getenv("FARHP_TOKEN_MAX_AGE", "43200"))
    demo_mode: bool = os.getenv("FARHP_DEMO_MODE", "1") == "1"
    deidentification_salt: str = os.getenv("FARHP_DEIDENTIFICATION_SALT", "farhp-v0.9-demo-deid-salt")
    app_name: str = "FARHP Research Server"
    app_version: str = "0.9.0"

settings = Settings()
