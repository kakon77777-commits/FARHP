# FARHP WebLab MVP v0.9

v0.9 在既有 FARHP WebLab v0.8 外圍加入 FastAPI／SQLite 協作服務。聲學合成與 ABX 工作流仍由瀏覽器執行；研究計畫、匿名邀請、電子同意、檢查點、完成資料、伺服器事件鏈及去識別分析改由伺服器集中管理。

## 快速啟動

```bash
python -m pip install -r requirements.txt
./start.sh
```

Windows 可執行 `start.bat`。開啟 `http://127.0.0.1:8000`。

Demo 模式預設建立三個帳號：

| 帳號 | 密碼 | 角色 |
|---|---|---|
| `admin` | `FarhpAdmin!2026` | principal investigator |
| `collector` | `Collector!2026` | data collector |
| `analyst` | `Analyst!2026` | analyst |

這些密碼只供本機 MVP。關閉 Demo 模式後，先執行：

```bash
python scripts/create_user.py neok principal_investigator --password "請換成強密碼"
```

公開部署前還必須設定獨立的 `FARHP_SECRET_KEY` 與 `FARHP_DEIDENTIFICATION_SALT`。

## 最小流程

1. 研究者登入並匯入 v0.8 研究計畫。
2. principal investigator 在伺服器端重新鎖定計畫。
3. 封存計畫並建立匿名邀請。
4. 受試者開啟邀請網址，完成同意並進入 WebLab。
5. WebLab 自動同步輕量檢查點，完成後提交完整 v0.8 study JSON。
6. 分析者登入查看去識別工作階段與群體摘要。

## API

互動文件位於 `/docs`。主要資源：

- `/api/plans`
- `/api/plans/{id}/lock`
- `/api/plans/{id}/archive`
- `/api/plans/{id}/invites`
- `/api/invites/{code}/sessions`
- `/api/participant/sessions/{id}/checkpoint`
- `/api/participant/sessions/{id}/complete`
- `/api/analysis/summary`

## 邊界

- SQLite 適合單機或小型研究，不適合高併發部署。
- 內建 token 是有時效的簽章權杖，不是完整 OAuth／OIDC。
- 伺服器封存是資料庫不可變工作流，不是外部可信時間戳或區塊鏈公證。
- 工作人員角色已由 API 強制執行；Demo UI 本身不是資安邊界。
- 本工具不等於倫理審查、法律電子簽章或正式醫療研究系統。
