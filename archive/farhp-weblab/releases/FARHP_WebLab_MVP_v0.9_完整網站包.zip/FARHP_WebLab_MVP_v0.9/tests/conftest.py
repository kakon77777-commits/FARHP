import os, sys
from pathlib import Path
import pytest
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
TEST_DB = ROOT / 'data' / 'pytest.sqlite3'
os.environ['FARHP_DATABASE_URL'] = f'sqlite:///{TEST_DB}'
os.environ['FARHP_DEMO_MODE'] = '1'
os.environ['FARHP_SECRET_KEY'] = 'test-secret'
os.environ['FARHP_DEIDENTIFICATION_SALT'] = 'test-deid'

from app.main import app, seed_demo
from app.db import Base, engine, SessionLocal

@pytest.fixture()
def client():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        seed_demo(db)
    with TestClient(app) as c:
        yield c
