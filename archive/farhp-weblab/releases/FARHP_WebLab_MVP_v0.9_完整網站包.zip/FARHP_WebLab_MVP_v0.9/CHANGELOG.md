# CHANGELOG

## v0.9.0

- 新增 FastAPI REST API 與 SQLite 持久化。
- 新增 principal investigator、data collector、analyst 三種伺服器角色。
- 新增伺服器端計畫重新鎖定、SHA-256 指紋與資料庫封存。
- 新增匿名邀請、電子同意、工作階段權杖及多人資料收集。
- 新增輕量檢查點自動同步與完成 study JSON 提交。
- 新增伺服器事件雜湊鏈與驗證端點。
- 新增分析者去識別讀取與群體統計摘要。
- 保留完整 v0.8 WebLab，加入同源 server bridge。
- 新增 Dockerfile、Compose、API 測試與 Chromium 端到端測試。
