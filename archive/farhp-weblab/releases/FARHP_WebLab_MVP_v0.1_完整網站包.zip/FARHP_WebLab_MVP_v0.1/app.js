'use strict';

const TAU = Math.PI * 2;
const SAMPLE_RATE = 24000;
const FORMANTS = {
  a: [[730, 100, 1.00], [1090, 140, 0.75], [2440, 180, 0.45]],
  i: [[270, 80, 1.00], [2290, 120, 0.80], [3010, 160, 0.35]],
  u: [[300, 90, 1.00], [870, 110, 0.75], [2240, 170, 0.35]],
  e: [[530, 90, 1.00], [1840, 130, 0.75], [2480, 170, 0.40]],
  o: [[570, 100, 1.00], [840, 120, 0.80], [2410, 180, 0.35]],
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const wrapPhase = (x) => ((x + Math.PI) % TAU + TAU) % TAU - Math.PI;
const circularDistance = (a, b) => Math.abs(wrapPhase(a - b));
const fmt = (v, digits = 3) => Number(v).toFixed(digits);

const state = {
  f0: 125,
  duration: 0.8,
  K: 24,
  anchor: 0.35,
  gain: 0.8,
  vowel: 'a',
  phasePreset: 'curved',
  strength: 1,
  quantM: 16,
  amplitudes: [],
  basePhase: [],
  targetPhase: [],
  phase: [],
  audio: null,
  audioCtx: null,
  source: null,
  analysis: null,
  baseline: null,
  randomSeed: 20260726,
};

function mulberry32(seed) {
  return function rng() {
    let t = seed += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function formantEnvelope(freq, formants) {
  let e = 0.02;
  for (const [center, bandwidth, gain] of formants) {
    const sigma = Math.max(bandwidth / 2.355, 1);
    e += gain * Math.exp(-0.5 * ((freq - center) / sigma) ** 2);
  }
  return e;
}

function makeAmplitudes(vowel, K, f0) {
  const arr = new Array(K);
  for (let i = 0; i < K; i++) {
    const k = i + 1;
    const env = vowel === 'flat' ? 1 : formantEnvelope(k * f0, FORMANTS[vowel]);
    arr[i] = env / Math.pow(k, 0.85);
  }
  const max = Math.max(...arr, 1e-9);
  return arr.map(v => v / max);
}

function phasePreset(name, K) {
  const p = new Array(K).fill(0);
  const rng = mulberry32(state.randomSeed);
  for (let i = 1; i < K; i++) {
    const k = i + 1;
    if (name === 'aligned') p[i] = 0;
    else if (name === 'curved') p[i] = wrapPhase(0.32 * Math.sqrt(k) + 0.075 * k * k / K);
    else if (name === 'alternating') p[i] = wrapPhase((k % 2) * Math.PI * 0.72 + 0.11 * k);
    else if (name === 'random') p[i] = -Math.PI + TAU * rng();
    else p[i] = state.phase[i] ?? 0;
  }
  return p;
}

function geodesicInterpolate(a, b, lambda) {
  return wrapPhase(a + lambda * wrapPhase(b - a));
}

function quantizePhase(x, M) {
  if (!M) return { value: wrapPhase(x), code: '∞' };
  const step = TAU / M;
  const code = ((Math.round((wrapPhase(x) + Math.PI) / step) % M) + M) % M;
  return { value: wrapPhase(-Math.PI + code * step), code };
}

function rebuildModel({ preserveCustom = false } = {}) {
  const oldAmp = state.amplitudes.slice();
  const oldPhase = state.phase.slice();
  state.amplitudes = makeAmplitudes(state.vowel, state.K, state.f0);
  if (preserveCustom) {
    for (let i = 0; i < Math.min(oldAmp.length, state.K); i++) state.amplitudes[i] = oldAmp[i];
  }
  state.basePhase = new Array(state.K).fill(0);
  state.targetPhase = phasePreset(state.phasePreset, state.K);
  state.phase = state.targetPhase.map((v, i) => geodesicInterpolate(state.basePhase[i], v, state.strength));
  if (state.phasePreset === 'custom' && preserveCustom) {
    for (let i = 0; i < Math.min(oldPhase.length, state.K); i++) state.phase[i] = oldPhase[i];
  }
  state.phase[0] = 0;
  updateAll();
}

function currentQuantizedPhase() {
  return state.phase.map((v, i) => i === 0 ? 0 : quantizePhase(v, state.quantM).value);
}

function synthesize() {
  const count = Math.max(1, Math.round(state.duration * SAMPLE_RATE));
  const out = new Float32Array(count);
  const phase = currentQuantizedPhase();
  const nyquist = SAMPLE_RATE / 2;
  for (let n = 0; n < count; n++) {
    const t = n / SAMPLE_RATE;
    let y = 0;
    for (let i = 0; i < state.K; i++) {
      const k = i + 1;
      if (k * state.f0 >= nyquist) break;
      y += state.amplitudes[i] * Math.cos(TAU * k * state.f0 * t + k * state.anchor + phase[i]);
    }
    out[n] = y;
  }
  let peak = 0;
  for (const v of out) peak = Math.max(peak, Math.abs(v));
  const scale = peak > 1e-9 ? state.gain / peak : 1;
  const fadeN = Math.min(Math.round(0.015 * SAMPLE_RATE), Math.floor(count / 4));
  for (let n = 0; n < count; n++) {
    let fade = 1;
    if (n < fadeN) fade = n / Math.max(1, fadeN);
    else if (n >= count - fadeN) fade = (count - 1 - n) / Math.max(1, fadeN);
    out[n] *= scale * clamp(fade, 0, 1);
  }
  state.audio = out;
  return { samples: out, rawPeak: peak };
}

async function playAudio() {
  stopAudio();
  const { samples } = synthesize();
  state.audioCtx ??= new (window.AudioContext || window.webkitAudioContext)({ sampleRate: SAMPLE_RATE });
  if (state.audioCtx.state === 'suspended') await state.audioCtx.resume();
  const buffer = state.audioCtx.createBuffer(1, samples.length, SAMPLE_RATE);
  buffer.copyToChannel(samples, 0);
  const source = state.audioCtx.createBufferSource();
  source.buffer = buffer;
  source.connect(state.audioCtx.destination);
  source.onended = () => { if (state.source === source) state.source = null; };
  source.start();
  state.source = source;
}

function stopAudio() {
  if (state.source) {
    try { state.source.stop(); } catch (_) {}
    state.source.disconnect();
    state.source = null;
  }
}

function setupCanvas(canvas) {
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  const width = Math.max(1, Math.round(rect.width * dpr));
  const height = Math.max(1, Math.round(rect.height * dpr));
  if (canvas.width !== width || canvas.height !== height) {
    canvas.width = width;
    canvas.height = height;
  }
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { ctx, w: rect.width, h: rect.height };
}

function palette() {
  const cs = getComputedStyle(document.documentElement);
  return {
    text: cs.getPropertyValue('--text').trim(),
    muted: cs.getPropertyValue('--muted').trim(),
    line: cs.getPropertyValue('--line').trim(),
    accent: cs.getPropertyValue('--accent').trim(),
    accent2: cs.getPropertyValue('--accent-2').trim(),
    accent3: cs.getPropertyValue('--accent-3').trim(),
  };
}

function drawGrid(ctx, w, h, p) {
  ctx.clearRect(0, 0, w, h);
  ctx.strokeStyle = p.line;
  ctx.lineWidth = 1;
  for (let i = 1; i < 5; i++) {
    const y = h * i / 5;
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
  }
  for (let i = 1; i < 10; i++) {
    const x = w * i / 10;
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
  }
}

function drawWave() {
  const canvas = $('#waveCanvas');
  const { ctx, w, h } = setupCanvas(canvas);
  const p = palette();
  drawGrid(ctx, w, h, p);
  const { samples, rawPeak } = synthesize();
  const showN = Math.min(samples.length, Math.round(0.04 * SAMPLE_RATE));
  ctx.strokeStyle = p.accent2;
  ctx.lineWidth = 2;
  ctx.beginPath();
  for (let i = 0; i < showN; i++) {
    const x = i / Math.max(1, showN - 1) * w;
    const y = h / 2 - samples[i] / Math.max(state.gain, 1e-6) * h * 0.43;
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.stroke();
  ctx.fillStyle = p.muted;
  ctx.font = '12px sans-serif';
  ctx.fillText('0 ms', 8, h - 8);
  ctx.fillText('40 ms', w - 46, h - 8);
  $('#peakBadge').textContent = `Raw peak ${fmt(rawPeak, 2)}`;
}

function drawSpectrum() {
  const { ctx, w, h } = setupCanvas($('#spectrumCanvas'));
  const p = palette();
  ctx.clearRect(0, 0, w, h);
  const pad = { l: 34, r: 10, t: 12, b: 28 };
  const innerW = w - pad.l - pad.r, innerH = h - pad.t - pad.b;
  ctx.strokeStyle = p.line; ctx.beginPath(); ctx.moveTo(pad.l, pad.t); ctx.lineTo(pad.l, pad.t + innerH); ctx.lineTo(w - pad.r, pad.t + innerH); ctx.stroke();
  const barW = innerW / state.K;
  for (let i = 0; i < state.K; i++) {
    const a = clamp(state.amplitudes[i], 0, 1.25);
    const bh = a / 1.25 * innerH;
    const grad = ctx.createLinearGradient(0, pad.t + innerH - bh, 0, pad.t + innerH);
    grad.addColorStop(0, p.accent);
    grad.addColorStop(1, p.accent2);
    ctx.fillStyle = grad;
    ctx.fillRect(pad.l + i * barW + 1, pad.t + innerH - bh, Math.max(1, barW - 2), bh);
  }
  ctx.fillStyle = p.muted; ctx.font = '11px sans-serif';
  ctx.fillText('Aₖ', 7, 16);
  ctx.fillText(`K=${state.K}`, w - 40, h - 7);
}

function drawPhaseWheel() {
  const { ctx, w, h } = setupCanvas($('#phaseCanvas'));
  const p = palette();
  ctx.clearRect(0, 0, w, h);
  const cx = w / 2, cy = h / 2, r = Math.min(w, h) * 0.36;
  ctx.strokeStyle = p.line; ctx.lineWidth = 1;
  for (const rr of [r * .35, r * .68, r]) { ctx.beginPath(); ctx.arc(cx, cy, rr, 0, TAU); ctx.stroke(); }
  for (let i = 0; i < 8; i++) { const a = i * TAU / 8; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + r * Math.cos(a), cy + r * Math.sin(a)); ctx.stroke(); }
  const q = currentQuantizedPhase();
  for (let i = 1; i < state.K; i++) {
    const angle = q[i];
    const rr = r * (0.38 + 0.62 * (i / Math.max(2, state.K - 1)));
    const x = cx + rr * Math.cos(angle), y = cy + rr * Math.sin(angle);
    ctx.fillStyle = i < 16 ? p.accent2 : p.accent;
    ctx.beginPath(); ctx.arc(x, y, i < 16 ? 3.3 : 2.1, 0, TAU); ctx.fill();
  }
  ctx.fillStyle = p.muted; ctx.font = '12px sans-serif';
  ctx.fillText('−π / π', cx - 18, cy + r + 18);
  ctx.fillText('0', cx + r + 7, cy + 4);
}

let heroT = 0;
function drawHero() {
  const canvas = $('#heroCanvas');
  if (!canvas) return;
  const { ctx, w, h } = setupCanvas(canvas);
  const p = palette();
  ctx.clearRect(0, 0, w, h);
  const cx = w / 2, cy = h / 2, maxR = Math.min(w, h) * .41;
  const phase = currentQuantizedPhase();
  for (let ring = 1; ring <= 5; ring++) {
    ctx.strokeStyle = p.line; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(cx, cy, maxR * ring / 5, 0, TAU); ctx.stroke();
  }
  for (let i = 1; i < Math.min(state.K, 28); i++) {
    const k = i + 1;
    const a = phase[i] + heroT * (.15 + i * .004);
    const r = maxR * (.22 + .76 * i / Math.min(state.K, 28));
    const x = cx + r * Math.cos(a), y = cy + r * Math.sin(a);
    ctx.strokeStyle = i % 2 ? p.accent : p.accent2;
    ctx.globalAlpha = .2 + .6 * state.amplitudes[i];
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(x, y); ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.fillStyle = i % 2 ? p.accent : p.accent2;
    ctx.beginPath(); ctx.arc(x, y, 2 + 5 * state.amplitudes[i], 0, TAU); ctx.fill();
    if (i < 9) { ctx.fillStyle = p.muted; ctx.font = '11px sans-serif'; ctx.fillText(String(k), x + 7, y + 3); }
  }
  ctx.fillStyle = p.text; ctx.font = '800 56px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('φ₁', cx, cy + 18); ctx.textAlign = 'start';
  heroT += .008;
  requestAnimationFrame(drawHero);
}

function renderHarmonicRows() {
  const tbody = $('#harmonicRows');
  tbody.textContent = '';
  const visible = Math.min(16, state.K);
  for (let i = 0; i < visible; i++) {
    const k = i + 1;
    const tr = document.createElement('tr');
    const q = quantizePhase(state.phase[i], state.quantM);
    tr.innerHTML = `
      <td>${k}</td>
      <td>${fmt(k * state.f0, 0)} Hz</td>
      <td><input class="amp-slider" data-i="${i}" type="range" min="0" max="1.25" step="0.005" value="${state.amplitudes[i]}"><output>${fmt(state.amplitudes[i], 2)}</output></td>
      <td>${i === 0 ? '<span class="muted">錨點</span>' : `<input class="phase-slider" data-i="${i}" type="range" min="-3.1416" max="3.1416" step="0.01" value="${state.phase[i]}"><output>${fmt(state.phase[i], 2)}</output>`}</td>
      <td><span class="phase-code">${i === 0 ? 'A' : q.code}</span></td>`;
    tbody.appendChild(tr);
  }
  $$('.amp-slider').forEach(el => el.addEventListener('input', e => {
    const i = Number(e.target.dataset.i);
    state.amplitudes[i] = Number(e.target.value);
    e.target.nextElementSibling.value = fmt(state.amplitudes[i], 2);
    updateVisualsOnly();
  }));
  $$('.phase-slider').forEach(el => el.addEventListener('input', e => {
    const i = Number(e.target.dataset.i);
    state.phasePreset = 'custom'; $('#phasePreset').value = 'custom';
    state.phase[i] = Number(e.target.value);
    e.target.nextElementSibling.value = fmt(state.phase[i], 2);
    updateVisualsOnly();
    renderHarmonicRows();
  }));
}

function quantMetrics() {
  if (!state.quantM) return { rmse: 0, max: 0, bound: 0 };
  const errors = state.phase.slice(1).map(v => circularDistance(v, quantizePhase(v, state.quantM).value));
  const rmse = Math.sqrt(errors.reduce((s, x) => s + x * x, 0) / Math.max(1, errors.length));
  return { rmse, max: Math.max(0, ...errors), bound: Math.PI / state.quantM };
}

function updateLabels() {
  $('#f0Out').value = `${fmt(state.f0, 0)} Hz`;
  $('#durationOut').value = `${fmt(state.duration, 2)} s`;
  $('#harmonicsOut').value = state.K;
  $('#anchorOut').value = `${fmt(state.anchor, 2)} rad`;
  $('#gainOut').value = `${Math.round(state.gain * 100)}%`;
  $('#strengthOut').value = fmt(state.strength, 2);
  $('#statF0').textContent = `${fmt(state.f0, 1)} Hz`;
  $('#statHarmonics').textContent = String(state.K);
  $('#statQuant').textContent = state.quantM ? `${state.quantM} 相` : '連續';
  const qm = quantMetrics();
  $('#statRmse').textContent = `${fmt(qm.rmse)} rad`;
}

function updateVisualsOnly() {
  updateLabels();
  drawWave(); drawSpectrum(); drawPhaseWheel();
}

function updateAll() {
  updateLabels(); renderHarmonicRows(); drawWave(); drawSpectrum(); drawPhaseWheel();
  runQuantTest(false);
}

function toast(message) {
  const el = $('#toast');
  el.textContent = message; el.classList.add('show');
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove('show'), 2600);
}

function objectUrlDownload(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function encodeWav(samples, sampleRate) {
  const buffer = new ArrayBuffer(44 + samples.length * 2);
  const view = new DataView(buffer);
  const write = (off, s) => [...s].forEach((c, i) => view.setUint8(off + i, c.charCodeAt(0)));
  write(0, 'RIFF'); view.setUint32(4, 36 + samples.length * 2, true); write(8, 'WAVE'); write(12, 'fmt ');
  view.setUint32(16, 16, true); view.setUint16(20, 1, true); view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true); view.setUint32(28, sampleRate * 2, true); view.setUint16(32, 2, true); view.setUint16(34, 16, true);
  write(36, 'data'); view.setUint32(40, samples.length * 2, true);
  let o = 44;
  for (const x of samples) { view.setInt16(o, Math.round(clamp(x, -1, 1) * 32767), true); o += 2; }
  return new Blob([buffer], { type: 'audio/wav' });
}

function specObject() {
  const q = currentQuantizedPhase();
  return {
    farhp_weblab_version: '0.1',
    generated_at: new Date().toISOString(),
    synthesis: { sample_rate_hz: SAMPLE_RATE, duration_sec: state.duration, f0_hz: state.f0, anchor_phase_rad: state.anchor, gain: state.gain, vowel_preset: state.vowel },
    phase: { representation: 'angle_rad', quantization_bins: state.quantM, preset: state.phasePreset, strength: state.strength, harmonic_indices: Array.from({ length: state.K - 1 }, (_, i) => i + 2), values: q.slice(1), continuous_values: state.phase.slice(1) },
    harmonics: { indices: Array.from({ length: state.K }, (_, i) => i + 1), amplitude: state.amplitudes.slice() },
    formula: 'psi_k = wrap(phi_k - k*phi_1)',
    scope: 'harmonic periodic synthesis MVP; not a complete speech vocoder',
  };
}

function loadSpec(obj) {
  const syn = obj.synthesis ?? obj.analysis ?? {};
  const phase = obj.phase ?? {};
  const harmonics = obj.harmonics ?? {};
  const amp = harmonics.amplitude ?? obj.amplitudes;
  const vals = phase.continuous_values ?? phase.values ?? obj.farhp_rad;
  if (!Array.isArray(amp) || !Array.isArray(vals)) throw new Error('JSON 缺少 harmonics.amplitude 或 phase.values');
  state.K = amp.length;
  state.f0 = Number(syn.f0_hz ?? state.f0);
  state.duration = Number(syn.duration_sec ?? state.duration);
  state.anchor = Number(syn.anchor_phase_rad ?? obj.anchor?.phase_rad ?? state.anchor);
  state.gain = Number(syn.gain ?? state.gain);
  state.vowel = syn.vowel_preset ?? 'flat';
  state.phasePreset = 'custom'; state.strength = 1;
  state.quantM = Number(phase.quantization_bins ?? 0);
  state.amplitudes = amp.map(Number);
  state.phase = vals.length === state.K ? vals.map(Number) : [0, ...vals.map(Number)];
  state.phase[0] = 0;
  state.basePhase = new Array(state.K).fill(0); state.targetPhase = state.phase.slice();
  syncControls(); updateAll();
}

function syncControls() {
  $('#f0').value = clamp(state.f0, 70, 320);
  $('#duration').value = clamp(state.duration, .2, 2);
  $('#harmonics').value = clamp(state.K, 4, 48);
  $('#anchor').value = clamp(state.anchor, -Math.PI, Math.PI);
  $('#gain').value = clamp(state.gain, .05, 1);
  $('#vowelPreset').value = FORMANTS[state.vowel] || state.vowel === 'flat' ? state.vowel : 'flat';
  $('#phasePreset').value = state.phasePreset;
  $('#strength').value = state.strength;
  $('#quantization').value = String(state.quantM);
}

function parseWav(arrayBuffer) {
  const view = new DataView(arrayBuffer);
  const str = (o, n) => Array.from({ length: n }, (_, i) => String.fromCharCode(view.getUint8(o + i))).join('');
  if (str(0, 4) !== 'RIFF' || str(8, 4) !== 'WAVE') throw new Error('不是有效的 RIFF/WAVE 檔');
  let offset = 12, fmtChunk = null, dataOffset = 0, dataSize = 0;
  while (offset + 8 <= view.byteLength) {
    const id = str(offset, 4); const size = view.getUint32(offset + 4, true); const start = offset + 8;
    if (id === 'fmt ') fmtChunk = { format: view.getUint16(start, true), channels: view.getUint16(start + 2, true), sampleRate: view.getUint32(start + 4, true), bits: view.getUint16(start + 14, true) };
    if (id === 'data') { dataOffset = start; dataSize = size; break; }
    offset = start + size + (size % 2);
  }
  if (!fmtChunk || !dataOffset) throw new Error('WAV 缺少 fmt 或 data 區塊');
  const { format, channels, sampleRate, bits } = fmtChunk;
  if (![1, 3].includes(format)) throw new Error(`目前只支援 PCM/IEEE float WAV（格式 ${format}）`);
  const bytes = bits / 8; const frames = Math.floor(dataSize / (bytes * channels)); const samples = new Float32Array(frames);
  const readSample = (o) => {
    if (format === 3 && bits === 32) return view.getFloat32(o, true);
    if (bits === 8) return (view.getUint8(o) - 128) / 128;
    if (bits === 16) return view.getInt16(o, true) / 32768;
    if (bits === 24) { let x = view.getUint8(o) | view.getUint8(o + 1) << 8 | view.getUint8(o + 2) << 16; if (x & 0x800000) x |= 0xff000000; return x / 8388608; }
    if (bits === 32) return view.getInt32(o, true) / 2147483648;
    throw new Error(`不支援 ${bits}-bit WAV`);
  };
  for (let i = 0; i < frames; i++) {
    let sum = 0;
    for (let c = 0; c < channels; c++) sum += readSample(dataOffset + (i * channels + c) * bytes);
    samples[i] = sum / channels;
  }
  return { sampleRate, samples, channels, bits };
}

function hann(n, N) { return N <= 1 ? 1 : 0.5 - 0.5 * Math.cos(TAU * n / (N - 1)); }

function estimateF0(samples, sr, minHz = 60, maxHz = 400) {
  const maxLag = Math.min(Math.floor(sr / minHz), samples.length - 2);
  const minLag = Math.max(2, Math.floor(sr / maxHz));
  let mean = 0; for (const x of samples) mean += x; mean /= samples.length;
  const x = new Float64Array(samples.length); let energy = 0;
  for (let i = 0; i < samples.length; i++) { x[i] = (samples[i] - mean) * hann(i, samples.length); energy += x[i] * x[i]; }
  if (energy < 1e-9) throw new Error('框架能量太低，無法估計基頻');
  const corr = new Float64Array(maxLag + 1);
  let bestLag = minLag, best = -Infinity;
  for (let lag = minLag; lag <= maxLag; lag++) {
    let s = 0, a = 0, b = 0;
    for (let i = 0; i < x.length - lag; i++) { const u = x[i], v = x[i + lag]; s += u * v; a += u * u; b += v * v; }
    corr[lag] = s / Math.sqrt(Math.max(a * b, 1e-16));
    if (corr[lag] > best) { best = corr[lag]; bestLag = lag; }
  }
  if (bestLag > minLag && bestLag < maxLag) {
    const ym = corr[bestLag - 1], y0 = corr[bestLag], yp = corr[bestLag + 1];
    const denom = ym - 2 * y0 + yp;
    if (Math.abs(denom) > 1e-9) bestLag += 0.5 * (ym - yp) / denom;
  }
  return { f0: sr / bestLag, confidence: clamp(best, 0, 1) };
}

function analyzeHarmonics(samples, sr, f0, K) {
  const N = samples.length; let mean = 0; for (const x of samples) mean += x; mean /= N;
  const coeffs = [], amps = [], phases = [];
  let windowSum = 0; for (let n = 0; n < N; n++) windowSum += hann(n, N);
  for (let k = 1; k <= K; k++) {
    if (k * f0 >= sr / 2) break;
    let re = 0, im = 0;
    for (let n = 0; n < N; n++) {
      const x = (samples[n] - mean) * hann(n, N);
      const a = TAU * k * f0 * n / sr;
      re += x * Math.cos(a); im -= x * Math.sin(a);
    }
    const c = { re, im }; coeffs.push(c);
    amps.push(2 * Math.hypot(re, im) / Math.max(windowSum, 1));
    phases.push(Math.atan2(im, re));
  }
  const maxAmp = Math.max(...amps, 1e-9); const normalized = amps.map(v => v / maxAmp);
  const anchor = phases[0] ?? 0;
  const farhp = phases.map((phi, i) => i === 0 ? 0 : wrapPhase(phi - (i + 1) * anchor));
  const threshold = maxAmp * 0.025;
  const mask = amps.map(v => v >= threshold);
  return { amplitudes: normalized, rawAmplitudes: amps, phases, farhp, anchor, mask, valid: mask.filter(Boolean).length };
}

async function analyzeWavFile(file) {
  $('#analysisState').textContent = '分析中'; $('#analysisState').className = 'status-badge neutral';
  try {
    const wav = parseWav(await file.arrayBuffer());
    const frameSec = Math.min(0.08, wav.samples.length / wav.sampleRate);
    const frameN = Math.min(wav.samples.length, Math.max(256, Math.round(frameSec * wav.sampleRate)));
    const center = Math.floor(wav.samples.length / 2); const start = clamp(center - Math.floor(frameN / 2), 0, wav.samples.length - frameN);
    const frame = wav.samples.slice(start, start + frameN);
    const f0est = estimateF0(frame, wav.sampleRate);
    const maxK = Math.min(48, Math.floor((wav.sampleRate / 2 - 1) / f0est.f0));
    const h = analyzeHarmonics(frame, wav.sampleRate, f0est.f0, maxK);
    const grade = f0est.confidence > .82 && h.valid >= 10 ? 4 : f0est.confidence > .65 && h.valid >= 6 ? 3 : f0est.confidence > .45 ? 2 : 1;
    state.analysis = { fileName: file.name, sampleRate: wav.sampleRate, duration: wav.samples.length / wav.sampleRate, frameStart: start / wav.sampleRate, frameLength: frameN / wav.sampleRate, f0: f0est.f0, confidence: f0est.confidence, grade, ...h };
    $('#aSampleRate').textContent = `${wav.sampleRate} Hz / ${wav.bits}-bit`;
    $('#aF0').textContent = `${fmt(f0est.f0, 2)} Hz`;
    $('#aConfidence').textContent = fmt(f0est.confidence, 3);
    $('#aHarmonics').textContent = `${h.valid}/${h.amplitudes.length}`;
    $('#aFrameTime').textContent = `${fmt(start / wav.sampleRate, 3)}–${fmt((start + frameN) / wav.sampleRate, 3)} s`;
    $('#aGrade').textContent = `Γ=${grade}`;
    $('#analysisState').textContent = '完成'; $('#analysisState').className = 'status-badge';
    $('#useAnalysisBtn').disabled = false; $('#analysisJsonBtn').disabled = false;
    $('#analysisNote').textContent = `${file.name}：中央框架已抽取。請把結果載入實驗台，進行重合成與相位對照。`;
    toast('WAV 分析完成');
  } catch (err) {
    $('#analysisState').textContent = '失敗'; $('#analysisState').className = 'status-badge';
    $('#analysisNote').textContent = err.message;
    toast(`分析失敗：${err.message}`);
  }
}

function analysisSpec() {
  const a = state.analysis;
  return {
    farhp_weblab_analysis_version: '0.1', file_name: a.fileName,
    analysis: { sample_rate_hz: a.sampleRate, frame_time_sec: a.frameStart, frame_length_sec: a.frameLength, f0_hz: a.f0, f0_confidence: a.confidence, applicability_grade: a.grade, method: 'browser_autocorrelation_harmonic_projection' },
    anchor: { type: 'fundamental', phase_rad: a.anchor, confidence: a.confidence },
    harmonics: { indices: a.amplitudes.map((_, i) => i + 1), amplitude: a.amplitudes, raw_amplitude: a.rawAmplitudes, absolute_phase_rad: a.phases, mask: a.mask.map(Number) },
    phase: { representation: 'angle_rad', harmonic_indices: a.farhp.slice(1).map((_, i) => i + 2), values: a.farhp.slice(1) },
    warning: 'single-frame MVP estimate; not glottal FARHP and not a physiological ground truth',
  };
}

function runShiftTest(showToast = true) {
  const dt = Number($('#shift').value) / 1000;
  const q = currentQuantizedPhase();
  let maxErr = 0;
  for (let i = 0; i < state.K; i++) {
    const k = i + 1;
    const phi = k * state.anchor + q[i];
    const shiftedPhi = phi - TAU * k * state.f0 * dt;
    const shiftedAnchor = state.anchor - TAU * state.f0 * dt;
    const recovered = i === 0 ? 0 : wrapPhase(shiftedPhi - k * shiftedAnchor);
    maxErr = Math.max(maxErr, circularDistance(recovered, q[i]));
  }
  const pass = maxErr < 1e-9;
  const el = $('#shiftResult'); el.className = `test-result ${pass ? 'pass' : 'fail'}`; el.textContent = `${pass ? 'PASS' : 'FAIL'}｜最大環距誤差 ${maxErr.toExponential(2)} rad`;
  if (showToast) toast(pass ? '時間平移不變性通過' : '時間平移不變性未通過');
}

function runQuantTest(showToast = true) {
  const m = quantMetrics();
  $('#quantRmse').textContent = `${fmt(m.rmse)} rad`; $('#quantMax').textContent = `${fmt(m.max)} rad`; $('#quantBound').textContent = state.quantM ? `${fmt(m.bound)} rad` : '0';
  const pass = !state.quantM || m.max <= m.bound + 1e-9;
  const el = $('#quantResult'); el.className = `test-result ${pass ? 'pass' : 'fail'}`; el.textContent = state.quantM ? `${pass ? 'PASS' : 'FAIL'}｜${state.quantM} 相量化符合 π/M 誤差界` : 'PASS｜目前使用連續相位，無量化誤差';
  if (showToast) toast('量化測試已更新');
}

function captureBaseline() {
  state.baseline = { f0: state.f0, duration: state.duration, anchor: state.anchor, amplitudes: state.amplitudes.slice(), phase: state.phase.slice() };
  const el = $('#invariantResult'); el.className = 'test-result pass'; el.textContent = '已捕捉基準。現在改變相位條件，再執行比較。';
  toast('FARHP-only 基準已建立');
}

function runInvariantTest() {
  if (!state.baseline) return captureBaseline();
  const b = state.baseline;
  const f0Same = Math.abs(b.f0 - state.f0) < 1e-9, durSame = Math.abs(b.duration - state.duration) < 1e-9, anchorSame = circularDistance(b.anchor, state.anchor) < 1e-9;
  const ampSame = b.amplitudes.length === state.amplitudes.length && b.amplitudes.every((v, i) => Math.abs(v - state.amplitudes[i]) < 1e-9);
  const phaseMove = b.phase.length === state.phase.length ? Math.sqrt(b.phase.slice(1).reduce((s, v, i) => s + circularDistance(v, state.phase[i + 1]) ** 2, 0) / Math.max(1, b.phase.length - 1)) : Infinity;
  const pass = f0Same && durSame && anchorSame && ampSame;
  const el = $('#invariantResult'); el.className = `test-result ${pass ? 'pass' : 'fail'}`;
  el.textContent = `${pass ? 'PASS' : 'FAIL'}｜f₀ ${f0Same ? '✓' : '✗'}・振幅 ${ampSame ? '✓' : '✗'}・時長 ${durSame ? '✓' : '✗'}・錨相位 ${anchorSame ? '✓' : '✗'}｜FARHP 位移 ${Number.isFinite(phaseMove) ? fmt(phaseMove) : '維度不同'} rad`;
}

function bindControls() {
  const rangeMap = [
    ['#f0', 'f0', Number], ['#duration', 'duration', Number], ['#anchor', 'anchor', Number], ['#gain', 'gain', Number], ['#strength', 'strength', Number],
  ];
  for (const [sel, key, parse] of rangeMap) $(sel).addEventListener('input', e => {
    state[key] = parse(e.target.value);
    if (key === 'f0') state.amplitudes = makeAmplitudes(state.vowel, state.K, state.f0);
    if (key === 'strength') state.phase = state.targetPhase.map((v, i) => geodesicInterpolate(state.basePhase[i], v, state.strength));
    updateAll();
  });
  $('#harmonics').addEventListener('input', e => { state.K = Number(e.target.value); rebuildModel({ preserveCustom: state.phasePreset === 'custom' }); });
  $('#vowelPreset').addEventListener('change', e => { state.vowel = e.target.value; state.amplitudes = makeAmplitudes(state.vowel, state.K, state.f0); updateAll(); });
  $('#phasePreset').addEventListener('change', e => { state.phasePreset = e.target.value; state.targetPhase = phasePreset(state.phasePreset, state.K); state.phase = state.targetPhase.map((v, i) => geodesicInterpolate(0, v, state.strength)); updateAll(); });
  $('#quantization').addEventListener('change', e => { state.quantM = Number(e.target.value); updateAll(); });
  $('#playBtn').addEventListener('click', playAudio); $('#heroPlay').addEventListener('click', playAudio); $('#stopBtn').addEventListener('click', stopAudio);
  $('#resetBtn').addEventListener('click', () => { Object.assign(state, { f0:125, duration:.8, K:24, anchor:.35, gain:.8, vowel:'a', phasePreset:'curved', strength:1, quantM:16 }); syncControls(); rebuildModel(); toast('已重設'); });
  $('#normalizeAmpBtn').addEventListener('click', () => { const m = Math.max(...state.amplitudes, 1e-9); state.amplitudes = state.amplitudes.map(v => v / m); updateAll(); });
  $('#wavBtn').addEventListener('click', () => objectUrlDownload(encodeWav(synthesize().samples, SAMPLE_RATE), `farhp_${Math.round(state.f0)}Hz.wav`));
  $('#jsonBtn').addEventListener('click', () => objectUrlDownload(new Blob([JSON.stringify(specObject(), null, 2)], { type:'application/json' }), 'farhp_frame.json'));
  $('#jsonInput').addEventListener('change', async e => { try { loadSpec(JSON.parse(await e.target.files[0].text())); toast('JSON 已載入'); } catch (err) { toast(`JSON 載入失敗：${err.message}`); } e.target.value=''; });
  $('#shift').addEventListener('input', e => { $('#shiftOut').value = `${fmt(Number(e.target.value), 2)} ms`; });
  $('#runShiftTest').addEventListener('click', () => runShiftTest()); $('#runQuantTest').addEventListener('click', () => runQuantTest());
  $('#captureBaseline').addEventListener('click', captureBaseline); $('#runInvariantTest').addEventListener('click', runInvariantTest);
  $('#chooseWavBtn').addEventListener('click', () => $('#wavInput').click()); $('#wavInput').addEventListener('change', e => e.target.files[0] && analyzeWavFile(e.target.files[0]));
  const drop = $('#wavDrop');
  ['dragenter','dragover'].forEach(n => drop.addEventListener(n, e => { e.preventDefault(); drop.classList.add('dragging'); }));
  ['dragleave','drop'].forEach(n => drop.addEventListener(n, e => { e.preventDefault(); drop.classList.remove('dragging'); }));
  drop.addEventListener('drop', e => { const f = e.dataTransfer.files[0]; if (f) analyzeWavFile(f); });
  $('#useAnalysisBtn').addEventListener('click', () => {
    const a = state.analysis; state.f0 = a.f0; state.K = a.amplitudes.length; state.duration = .8; state.anchor = a.anchor; state.vowel = 'flat'; state.phasePreset = 'custom'; state.strength = 1; state.quantM = 0;
    state.amplitudes = a.amplitudes.slice(); state.phase = a.farhp.slice(); state.basePhase = new Array(state.K).fill(0); state.targetPhase = state.phase.slice(); syncControls(); updateAll();
    location.hash = '#lab'; toast('分析結果已載入合成實驗台');
  });
  $('#analysisJsonBtn').addEventListener('click', () => objectUrlDownload(new Blob([JSON.stringify(analysisSpec(), null, 2)], { type:'application/json' }), 'farhp_analysis.json'));
  $('#themeToggle').addEventListener('click', () => { const root = document.documentElement; root.dataset.theme = root.dataset.theme === 'light' ? 'dark' : 'light'; localStorage.setItem('farhp-theme', root.dataset.theme); updateVisualsOnly(); });
  window.addEventListener('resize', () => { drawWave(); drawSpectrum(); drawPhaseWheel(); });
}

function init() {
  document.documentElement.dataset.theme = localStorage.getItem('farhp-theme') || 'dark';
  bindControls(); syncControls(); rebuildModel(); drawHero(); runShiftTest(false); captureBaseline();
}

document.addEventListener('DOMContentLoaded', init);
