'use strict';
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');

const code = fs.readFileSync(require('path').join(__dirname, '..', 'app.js'), 'utf8');
const context = vm.createContext({
  console,
  Math,
  Number,
  Array,
  ArrayBuffer,
  DataView,
  Float32Array,
  Float64Array,
  Uint8Array,
  Blob,
  Date,
  JSON,
  setTimeout,
  clearTimeout,
  document: { querySelector: () => null, querySelectorAll: () => [], addEventListener: () => {} },
  window: {},
  localStorage: { getItem: () => null, setItem: () => {} },
  URL: { createObjectURL: () => '', revokeObjectURL: () => {} },
  location: { hash: '' },
  requestAnimationFrame: () => 0,
});
vm.runInContext(code, context, { filename: 'app.js' });
const ev = expr => vm.runInContext(expr, context);
const near = (a, b, eps=1e-9) => assert.ok(Math.abs(a-b) <= eps, `${a} != ${b}`);

// wrap_phase belongs to (-pi, pi]. Numerical representation uses [-pi, pi).
for (const x of [-100, -Math.PI, -1, 0, 1, Math.PI, 100]) {
  const y = ev(`wrapPhase(${x})`);
  assert.ok(y >= -Math.PI - 1e-12 && y < Math.PI + 1e-12);
}
near(ev('circularDistance(Math.PI-0.01, -Math.PI+0.01)'), 0.02, 1e-9);

// Quantization must stay inside pi/M.
for (const M of [8,16,32,64]) {
  for (let i=0; i<1000; i++) {
    const x = -Math.PI + 2*Math.PI*i/999;
    const err = ev(`circularDistance(${x}, quantizePhase(${x}, ${M}).value)`);
    assert.ok(err <= Math.PI/M + 1e-9, `quantization bound failed M=${M}, err=${err}`);
  }
}

// Fundamental-anchored relative phase is invariant to a common time shift.
const f0=137.5, anchor=0.47, dt=0.0073;
for (let k=1; k<=32; k++) {
  const psi = k===1 ? 0 : Math.sin(k*0.37);
  const phi = k*anchor + psi;
  const shiftedPhi = phi - 2*Math.PI*k*f0*dt;
  const shiftedAnchor = anchor - 2*Math.PI*f0*dt;
  const recovered = k===1 ? 0 : ev(`wrapPhase(${shiftedPhi} - ${k} * ${shiftedAnchor})`);
  near(ev(`circularDistance(${recovered}, ${psi})`), 0, 1e-9);
}

// Synthesis and browser autocorrelation estimator form a controlled closed loop.
ev(`Object.assign(state, {f0: 125, duration: 0.5, K: 20, anchor: 0.35, gain: 0.8, quantM: 0});
state.amplitudes = Array.from({length:20}, (_,i)=>1/Math.pow(i+1,0.9));
state.phase = Array.from({length:20}, (_,i)=>i===0?0:wrapPhase(0.12*(i+1)));
state.audio = null;`);
const estimate = ev(`(() => { const s=synthesize().samples; return estimateF0(s.slice(1000, 3000), SAMPLE_RATE); })()`);
assert.ok(Math.abs(estimate.f0 - 125) < 1.0, `f0 estimate ${estimate.f0}`);
assert.ok(estimate.confidence > 0.7, `confidence ${estimate.confidence}`);

// WAV writer emits a valid RIFF/WAVE header.
(async () => {
  const blob = ev(`encodeWav(synthesize().samples, SAMPLE_RATE)`);
  const buf = Buffer.from(await blob.arrayBuffer());
  assert.strictEqual(buf.subarray(0,4).toString('ascii'), 'RIFF');
  assert.strictEqual(buf.subarray(8,12).toString('ascii'), 'WAVE');
  assert.strictEqual(buf.subarray(36,40).toString('ascii'), 'data');
  console.log('FARHP WebLab self-test: 5 groups PASS');
})().catch(err => { console.error(err); process.exit(1); });
