# FARHP WebLab MVP v0.3

**基頻錨定相對諧波相位差 × 華語多音節語流合成器**

這是一個純前端、可離線執行的 FARHP 互動網站。v0.3 在 v0.2 的華語音節合成器之上，加入詞典聲調與表層聲調分離、三聲變調、語境輕聲、語句基頻下傾、句末延長與邊界交疊，形成第一個多音節語流閉環。

## 直接使用

解壓縮後開啟 `index.html`。若瀏覽器限制本機檔案，可執行：

```bash
python -m http.server 8000
```

或在 Windows 雙擊 `serve.bat`，再開啟：

```text
http://localhost:8000
```

網站不需要後端、不需要 API Key，音訊只在瀏覽器本機處理。

## v0.3 新增功能

### 多音節語流合成器

- 音節序列編輯與目前音節加入；
- 內建「你好」「你好嗎」「我很好」「媽媽好」；
- 詞典聲調與表層聲調分離；
- 局部三聲變調：

$$
3+3\rightarrow2+3;
$$

- 連續三聲在未指定韻律分組時採局部鏈式近似：

$$
3+3+3\rightarrow2+2+3;
$$

- 輕聲依前一表層聲調調整相對音高；
- 語速控制；
- 句末延長；
- 短語級基頻下傾；
- 音節邊界等功率交疊；
- 語句級 $f_0$ 圖與波形圖；
- 語流 WAV 與 JSON 匯出；
- 每音節 FARHP 來源與強度保留。

### 分層處理順序

$$
\text{詞典音系}
\rightarrow
\text{語境聲調實現}
\rightarrow
\text{短語韻律}
\rightarrow
\text{逐音節 FARHP}
\rightarrow
\text{邊界交疊}.
$$

這一順序避免把三聲變調、輕聲、語句韻律與 FARHP 混成同一個參數。

## 原有功能

- 22 種聲母選項，含零聲母；
- 37 種韻母／舌尖元音選項；
- 四呼類別檢查；
- 五聲連續 $f_0(t)$；
- 聲母爆破、送氣、塞擦、摩擦、鼻音、邊音與近音插槽；
- 前鼻音、後鼻音與兒化尾段模型；
- FARHP 諧波合成與逐諧波編輯；
- 8、16、32、64 相量化；
- WAV 匯入、基頻估計與相位抽取；
- 時間平移不變性與 FARHP-only 證書；
- 音節與語流 WAV／JSON 匯出。

## 範例

`examples/utterances/` 內含四組多音節 WAV 與 JSON：

```text
nihao.wav / .json
nihaoma.wav / .json
wohenhao.wav / .json
mamahao.wav / .json
```

重新產生：

```bash
node tools/generate_utterance_examples.cjs
```

原有「ㄇㄚ」五聲材料位於 `examples/mandarin_tones/`。

## 測試

```bash
node tests/selftest.cjs
python tests/browser_test.py
```

Node 自測共 13 組，新增涵蓋：

- 雙三聲與連續三聲表層實現；
- 輕聲前調語境；
- 多音節合成與邊界交疊；
- 語流 manifest 的詞典／表層聲調分離。

Chromium 測試會實際切換 `我很好`，確認表層輸出為：

$$
\text{ㄨㄛˊ　ㄏㄣˊ　ㄏㄠˇ},
$$

並檢查 WAV 合成、語流 manifest、原音節合成與 FARHP 不變性測試。

## JSON Schema

```text
spec/FARHP_Mandarin_Syllable_Spec_v0.3.schema.json
spec/FARHP_Mandarin_Utterance_Spec_v0.3.schema.json
```

四份語流示範 JSON 均已通過 Draft 2020-12 Schema 驗證。

## 目前邊界

本版本仍是**結構型聲學 MVP**，不是自然語音 TTS：

- 三聲變調尚未解析句法或韻律詞分組；
- 共構音目前是音訊邊界交疊代理，不是連續聲道參數模型；
- 輕聲音高使用可檢驗的粗分類，不代表完整方言／說話人模型；
- 未包含「一、不」變調；
- 未包含焦點、疑問、情緒與長句韻律；
- 未經自然語料訓練及人類盲聽驗證。

因此，v0.3 證明的是 FARHP 可以在不取代音系與韻律層的前提下，進入多音節發音工作流。
