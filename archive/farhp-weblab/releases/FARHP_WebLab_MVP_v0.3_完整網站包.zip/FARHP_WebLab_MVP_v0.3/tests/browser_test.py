from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
css = (ROOT / 'styles.css').read_text(encoding='utf-8')
js = (ROOT / 'app.js').read_text(encoding='utf-8')

# Test harness only: set_content has no persistent origin, so storage is bypassed.
js = js.replace("localStorage.getItem('farhp-theme') || 'dark'", "'dark'")
js = js.replace("localStorage.setItem('farhp-theme', root.dataset.theme);", "void 0;")
js = js.replace("document.addEventListener('DOMContentLoaded', init);", "init();")
html = html.replace('<link rel="stylesheet" href="styles.css">', f'<style>{css}</style>')
html = html.replace('<script src="app.js"></script>', f'<script>{js}</script>')

errors = []
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page(viewport={'width': 1440, 'height': 1200}, device_scale_factor=1)
    page.on('console', lambda msg: errors.append(f'console:{msg.type}:{msg.text}') if msg.type == 'error' else None)
    page.on('pageerror', lambda exc: errors.append(f'pageerror:{exc}'))
    page.set_content(html, wait_until='load')
    page.wait_for_timeout(500)

    assert page.locator('#initialSelect option').count() == 22
    assert page.locator('#finalSelect option').count() == 37
    assert page.locator('#syllableDisplay').inner_text() == 'ㄇㄚˇ'
    assert page.locator('#sequenceList .sequence-item').count() == 3
    assert page.locator('#utteranceLexical').inner_text() == 'ㄋㄧˇ　ㄏㄠˇ　˙ㄇㄚ'
    assert page.locator('#utteranceSurface').inner_text() == 'ㄋㄧˊ　ㄏㄠˇ　˙ㄇㄚ'

    page.select_option('#syllablePreset', 'xuan2')
    page.wait_for_timeout(100)
    assert page.locator('#syllableDisplay').inner_text() == 'ㄒㄩㄢˊ'
    assert '撮口呼' in page.locator('#metricSihu').inner_text()

    page.select_option('#syllablePreset', 'zhong1')
    page.wait_for_timeout(100)
    assert page.locator('#syllableDisplay').inner_text() == 'ㄓㄨㄥ'
    assert '/ŋ/' in page.locator('#metricCoda').inner_text()

    result = page.evaluate("""() => {
      const r = synthesizeSyllable();
      return {
        n: r.samples.length,
        min: r.f0Min,
        max: r.f0Max,
        finite: Array.from(r.samples.slice(0, 1000)).every(Number.isFinite),
        manifest: syllableManifest().phonology.bopomofo
      };
    }""")
    assert result['n'] > 10000
    assert result['finite']
    assert result['max'] >= result['min']
    assert result['manifest'] == 'ㄓㄨㄥ'

    page.select_option('#utterancePreset', 'wohenhao')
    page.wait_for_timeout(100)
    assert page.locator('#utteranceSurface').inner_text() == 'ㄨㄛˊ　ㄏㄣˊ　ㄏㄠˇ'
    assert '2 個三聲改寫' in page.locator('#utteranceRuleCertificate').inner_text()

    utterance_result = page.evaluate("""() => {
      const r = synthesizeUtterance();
      const m = utteranceManifest();
      return {n:r.samples.length, duration:r.duration, finite:Array.from(r.samples.slice(0,2000)).every(Number.isFinite), surface:m.surface_bopomofo};
    }""")
    assert utterance_result['n'] > 20000
    assert utterance_result['duration'] > 1
    assert utterance_result['finite']
    assert utterance_result['surface'] == ['ㄨㄛˊ','ㄏㄣˊ','ㄏㄠˇ']

    page.click('#runShiftTest')
    assert 'PASS' in page.locator('#shiftResult').inner_text()
    page.screenshot(path=str(ROOT / 'assets' / 'preview_v0.3.png'), full_page=True)
    browser.close()

if errors:
    raise RuntimeError('\n'.join(errors))

print('FARHP WebLab browser test: PASS')
print(result)
print(utterance_result)
