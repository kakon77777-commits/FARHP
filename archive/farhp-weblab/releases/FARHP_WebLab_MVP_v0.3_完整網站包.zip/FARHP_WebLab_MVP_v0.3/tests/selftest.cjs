'use strict';
const fs = require('fs');
const vm = require('vm');
const assert = require('assert');

const code = fs.readFileSync(require('path').join(__dirname, '..', 'app.js'), 'utf8');
const context = vm.createContext({
  console,
  Math,
  Number,
  Array,
  ArrayBuffer,
  DataView,
  Float32Array,
  Float64Array,
  Uint8Array,
  Blob,
  Date,
  JSON,
  setTimeout,
  clearTimeout,
  document: { querySelector: () => null, querySelectorAll: () => [], addEventListener: () => {} },
  window: {},
  localStorage: { getItem: () => null, setItem: () => {} },
  URL: { createObjectURL: () => '', revokeObjectURL: () => {} },
  location: { hash: '' },
  requestAnimationFrame: () => 0,
});
vm.runInContext(code, context, { filename: 'app.js' });
const ev = expr => vm.runInContext(expr, context);
const near = (a, b, eps=1e-9) => assert.ok(Math.abs(a-b) <= eps, `${a} != ${b}`);

// wrap_phase belongs to (-pi, pi]. Numerical representation uses [-pi, pi).
for (const x of [-100, -Math.PI, -1, 0, 1, Math.PI, 100]) {
  const y = ev(`wrapPhase(${x})`);
  assert.ok(y >= -Math.PI - 1e-12 && y < Math.PI + 1e-12);
}
near(ev('circularDistance(Math.PI-0.01, -Math.PI+0.01)'), 0.02, 1e-9);

// Quantization must stay inside pi/M.
for (const M of [8,16,32,64]) {
  for (let i=0; i<1000; i++) {
    const x = -Math.PI + 2*Math.PI*i/999;
    const err = ev(`circularDistance(${x}, quantizePhase(${x}, ${M}).value)`);
    assert.ok(err <= Math.PI/M + 1e-9, `quantization bound failed M=${M}, err=${err}`);
  }
}

// Fundamental-anchored relative phase is invariant to a common time shift.
const f0=137.5, anchor=0.47, dt=0.0073;
for (let k=1; k<=32; k++) {
  const psi = k===1 ? 0 : Math.sin(k*0.37);
  const phi = k*anchor + psi;
  const shiftedPhi = phi - 2*Math.PI*k*f0*dt;
  const shiftedAnchor = anchor - 2*Math.PI*f0*dt;
  const recovered = k===1 ? 0 : ev(`wrapPhase(${shiftedPhi} - ${k} * ${shiftedAnchor})`);
  near(ev(`circularDistance(${recovered}, ${psi})`), 0, 1e-9);
}

// Synthesis and browser autocorrelation estimator form a controlled closed loop.
ev(`Object.assign(state, {f0: 125, duration: 0.5, K: 20, anchor: 0.35, gain: 0.8, quantM: 0});
state.amplitudes = Array.from({length:20}, (_,i)=>1/Math.pow(i+1,0.9));
state.phase = Array.from({length:20}, (_,i)=>i===0?0:wrapPhase(0.12*(i+1)));
state.audio = null;`);
const estimate = ev(`(() => { const s=synthesize().samples; return estimateF0(s.slice(1000, 3000), SAMPLE_RATE); })()`);
assert.ok(Math.abs(estimate.f0 - 125) < 1.0, `f0 estimate ${estimate.f0}`);
assert.ok(estimate.confidence > 0.7, `confidence ${estimate.confidence}`);



// Mandarin tone trajectories preserve their intended contour classes.
assert.ok(ev('toneF0(2, 1, 130)') > ev('toneF0(2, 0, 130)'), 'tone 2 must rise');
assert.ok(ev('toneF0(4, 1, 130)') < ev('toneF0(4, 0, 130)'), 'tone 4 must fall');
assert.ok(ev('toneF0(3, .56, 130)') < ev('toneF0(3, 0, 130)') && ev('toneF0(3, .56, 130)') < ev('toneF0(3, 1, 130)'), 'tone 3 must dip');
assert.ok(Math.abs(ev('toneF0(1, 1, 130)') - ev('toneF0(1, 0, 130)')) < 3, 'tone 1 must remain level');

// Coarse four-hu phonotactics reject category-incompatible combinations.
assert.strictEqual(ev("isSyllableCategoryAllowed('ㄐ','van')"), true);
assert.strictEqual(ev("isSyllableCategoryAllowed('ㄐ','a')"), false);
assert.strictEqual(ev("isSyllableCategoryAllowed('ㄍ','i')"), false);
assert.strictEqual(ev("isSyllableCategoryAllowed('ㄋ','v')"), true);
assert.strictEqual(ev("isSyllableCategoryAllowed('ㄓ','apical')"), true);

// Dynamic syllable synthesis must produce a finite non-silent waveform and tone metadata.
ev(`Object.assign(syllableState, {initial:'ㄇ', final:'a', tone:3, baseF0:132, duration:.72, residualStrength:.5, phaseStrength:1, phaseSource:'curved'});`);
const syllable = ev('synthesizeSyllable()');
assert.ok(syllable.samples.length > 10000, `syllable length ${syllable.samples.length}`);
assert.ok(syllable.samples.every(Number.isFinite), 'syllable samples must be finite');
assert.ok(Math.max(...syllable.samples.map(Math.abs)) > .2, 'syllable must be non-silent');
assert.ok(syllable.f0Min < syllable.f0Max, 'tone 3 must have f0 range');

// The syllable manifest keeps tone, FARHP and residual layers separate.
const manifest = ev('syllableManifest()');
assert.strictEqual(manifest.phonology.bopomofo, 'ㄇㄚˇ');
assert.strictEqual(manifest.phonology.tone, 3);
assert.ok(Array.isArray(manifest.farhp.values) && manifest.farhp.values.length > 5);
assert.ok(manifest.acoustics.f0_min_hz < manifest.acoustics.f0_max_hz);



// Third-tone sandhi keeps lexical tone separate from surface realization.
ev(`utteranceState.sandhi=true; utteranceState.neutralContext=true; utteranceState.declination=true; utteranceState.speechRate=1; utteranceState.finalLengthening=.18; utteranceState.coarticulation=true; utteranceState.overlapMs=32;
utteranceState.items=UTTERANCE_PRESETS.nihao.map(normalizeUtteranceItem);`);
let realized = ev('realizeUtterance()');
assert.deepStrictEqual(Array.from(realized, x=>x.lexicalTone), [3,3]);
assert.deepStrictEqual(Array.from(realized, x=>x.surfaceTone), [2,3]);
assert.strictEqual(realized[0].sandhiApplied, true);

ev(`utteranceState.items=UTTERANCE_PRESETS.wohenhao.map(normalizeUtteranceItem);`);
realized = ev('realizeUtterance()');
assert.deepStrictEqual(Array.from(realized, x=>x.surfaceTone), [2,2,3]);

// Contextual neutral tone depends on the previous surface tone.
const neutralAfter3 = ev('neutralToneSemitones(3,.7)');
const neutralAfter4 = ev('neutralToneSemitones(4,.7)');
assert.ok(neutralAfter3 > neutralAfter4 + 5, `${neutralAfter3} vs ${neutralAfter4}`);

ev(`utteranceState.items=UTTERANCE_PRESETS.nihaoma.map(normalizeUtteranceItem);`);
realized = ev('realizeUtterance()');
assert.strictEqual(realized[2].surfaceTone, 0);
assert.strictEqual(realized[2].contextualNeutral, true);
assert.strictEqual(realized[2].contextPrevTone, 3);
assert.ok(realized[2].durationRealized < realized[1].durationRealized);

// Multi-syllable synthesis is finite and applies boundary overlap.
const utterance = ev('synthesizeUtterance()');
assert.strictEqual(utterance.realized.length, 3);
assert.ok(utterance.samples.length > 20000);
assert.ok(Array.from(utterance.samples.slice(0,2000)).every(Number.isFinite));
assert.ok(utterance.boundaries[1].overlap_samples > 0);
assert.ok(utterance.f0Max > utterance.f0Min);

// Utterance manifest preserves lexical/surface tones and per-syllable FARHP fields.
const utteranceManifestObj = ev('utteranceManifest()');
assert.deepStrictEqual(Array.from(utteranceManifestObj.syllables, x=>x.lexical_tone), [3,3,0]);
assert.deepStrictEqual(Array.from(utteranceManifestObj.syllables, x=>x.surface_tone), [2,3,0]);
assert.ok(utteranceManifestObj.syllables.every(x=>x.farhp && typeof x.farhp.source === 'string'));
assert.strictEqual(utteranceManifestObj.farhp_weblab_utterance_version, '0.3');

// WAV writer emits a valid RIFF/WAVE header.
(async () => {
  const blob = ev(`encodeWav(synthesize().samples, SAMPLE_RATE)`);
  const buf = Buffer.from(await blob.arrayBuffer());
  assert.strictEqual(buf.subarray(0,4).toString('ascii'), 'RIFF');
  assert.strictEqual(buf.subarray(8,12).toString('ascii'), 'WAVE');
  assert.strictEqual(buf.subarray(36,40).toString('ascii'), 'data');
  console.log('FARHP WebLab self-test: 13 groups PASS');
})().catch(err => { console.error(err); process.exit(1); });
