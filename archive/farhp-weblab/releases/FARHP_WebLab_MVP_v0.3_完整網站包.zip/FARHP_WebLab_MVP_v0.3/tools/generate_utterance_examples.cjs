'use strict';
const fs=require('fs');
const path=require('path');
const vm=require('vm');
const root=path.resolve(__dirname,'..');
const code=fs.readFileSync(path.join(root,'app.js'),'utf8');
const context=vm.createContext({
  console,Math,Number,Array,ArrayBuffer,DataView,Float32Array,Float64Array,Uint8Array,Blob,Date,JSON,
  setTimeout,clearTimeout,document:{querySelector:()=>null,querySelectorAll:()=>[],addEventListener:()=>{}},window:{},
  localStorage:{getItem:()=>null,setItem:()=>{}},URL:{createObjectURL:()=>'',revokeObjectURL:()=>{}},location:{hash:''},requestAnimationFrame:()=>0,
});
vm.runInContext(code,context,{filename:'app.js'});
const run=expr=>vm.runInContext(expr,context);
const outDir=path.join(root,'examples','utterances');fs.mkdirSync(outDir,{recursive:true});
const presets=['nihao','nihaoma','wohenhao','mamahao'];
(async()=>{
  for(const preset of presets){
    run(`utteranceState.sandhi=true;utteranceState.neutralContext=true;utteranceState.coarticulation=true;utteranceState.declination=true;utteranceState.speechRate=1;utteranceState.overlapMs=32;utteranceState.finalLengthening=.18;utteranceState.items=UTTERANCE_PRESETS.${preset}.map(normalizeUtteranceItem);utteranceState.lastMeta=null;`);
    const manifest=run('utteranceManifest()');
    fs.writeFileSync(path.join(outDir,`${preset}.json`),JSON.stringify(manifest,null,2));
    const blob=run('encodeWav(synthesizeUtterance().samples,SAMPLE_RATE)');
    fs.writeFileSync(path.join(outDir,`${preset}.wav`),Buffer.from(await blob.arrayBuffer()));
  }
  console.log(`Generated ${presets.length} utterance WAV/JSON pairs.`);
})().catch(err=>{console.error(err);process.exit(1);});
