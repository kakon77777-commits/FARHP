# FARHP WebLab MVP v0.5 測試報告

## 1. 測試目的

v0.5 的新增目標不是證明 FARHP 已具有知覺優勢，而是驗證它能進入一個最小、可重複的盲聽工作流：

$$
\text{固定語流}
\rightarrow
\text{FARHP-only 刺激對}
\rightarrow
\text{固定種子隨機化}
\rightarrow
\text{ABX 回答}
\rightarrow
\text{結果與證書匯出}.
$$

## 2. 執行環境

- 純前端 HTML／CSS／JavaScript；
- 音訊取樣率：$$24{,}000\ \mathrm{Hz}$$；
- Node.js 回歸測試；
- Chromium／Playwright 端到端測試；
- JSON Schema Draft 2020-12 驗證。

## 3. 總結

| 項目 | 結果 |
|---|---:|
| JavaScript 語法 | PASS |
| Node 回歸測試 | 24 組 PASS |
| Chromium 端到端測試 | PASS |
| 瀏覽器控制台錯誤 | 0 |
| 音節 Schema | 5／5 PASS |
| 語流 Schema | 7／7 PASS |
| ABX 實驗 Schema | 1／1 PASS |
| 全部範例 Schema | 13／13 PASS |
| ZIP 內容完整性 | PASS |

## 4. FARHP-only 刺激證書

範例實驗使用：

- 語流：「你好嗎」；
- 基準：目前語流 FARHP；
- 介入：80% 零相位；
- 種子：`424242`。

證書結果：

| 指標 | 結果 |
|---|---:|
| 樣本數相同 | PASS |
| 時長相同 | PASS |
| 詞典注音相同 | PASS |
| 表層注音相同 | PASS |
| 最大逐樣本 $$f_0$$ 差 | $$0\ \mathrm{Hz}$$ |
| 波形 RMS 位移 | $$0.0859995$$ |
| 綜合證書 | PASS |

因此在此受控例中：

$$
\boxed{
\Delta f_0[n]=0
}
$$

但聲波確實不同：

$$
\boxed{
\operatorname{RMS}(x_{\mathrm{base}}-x_{\mathrm{phase}})>0
}.
$$

## 5. 隨機相位可重複性

測試以相同條件生成三份刺激：

- `randomA`：種子 `424242`；
- `randomB`：種子 `424242`；
- `randomC`：種子 `424243`。

結果：

$$
\operatorname{randomA}=\operatorname{randomB}
$$

逐樣本完全一致；不同種子則產生非零波形差異。

## 6. ABX 工作流

Chromium 端到端測試完成四輪 ABX：

- 建立固定種子實驗；
- 驗證建立期間正確率顯示為「封存」；
- 完成前表格不揭示條件；
- 模擬 A／B／X 各播放一次；
- 逐輪提交回答；
- 完成後揭示映射；
- 啟用 JSON 與 CSV 匯出；
- CSV 共五行：一行表頭、四行試驗。

自動測試故意提交每輪正確答案，因此測得：

$$
4/4=100\%.
$$

這只是 UI 與統計管線測試，**不是人類受試者結果**。

## 7. 既有華語回歸測試

### 聲調

- 二聲上升；
- 四聲下降；
- 三聲低谷；
- 一聲近似平直；
- 輕聲受前一表層聲調影響。

### 變調

$$
3+3\rightarrow2+3,
$$

$$
3+3+3\rightarrow2+2+3,
$$

$$
\text{一}+4\rightarrow2+4,
$$

$$
\text{一}+1\rightarrow4+1,
$$

$$
\text{不}+4\rightarrow2+4.
$$

### 韻律分組

「我很好｜你呢」建立一個組間停頓：

$$
2{,}160\ \text{samples}=90\ \mathrm{ms}.
$$

停頓內 $$f_0=0$$，且跨組聲道上下文不傳播。

### 句調

「你好嗎」測試中：

| 句型 | 句尾平均基頻 |
|---|---:|
| 疑問句 | $$173.843\ \mathrm{Hz}$$ |
| 陳述句 | $$126.845\ \mathrm{Hz}$$ |

疑問句句尾高於陳述句 15% 以上。

## 8. 交換規格

下列規格及範例均通過 Draft 2020-12 驗證：

```text
spec/FARHP_Mandarin_Syllable_Spec_v0.5.schema.json
spec/FARHP_Mandarin_Utterance_Spec_v0.5.schema.json
spec/FARHP_ABX_Experiment_Spec_v0.5.schema.json
```

## 9. 已知限制

目前 ABX 實驗仍存在以下限制：

- 同一瀏覽器、單一使用者；
- 同一語流在多輪中反覆出現；
- 沒有耳機校準與播放音量鎖定；
- 沒有受試者匿名 ID、伺服器收件或研究同意流程；
- 沒有試驗間靜默期與強制播放順序；
- 沒有信號檢測指標、功效分析與群體統計；
- 合成語音自然度尚不足以代表真人語音。

## 10. 判定

v0.5 已通過以下最小工程判定：

$$
\boxed{
\text{可重複刺激}
+
\text{條件封存}
+
\text{ABX 回答}
+
\text{反應時間}
+
\text{結果匯出}
+
\text{FARHP-only 證書}
}
$$

因此 FARHP WebLab 已由合成展示站推進為**最小可操作知覺實驗工具**；科學結論仍需自然語料、多受試者與正式統計設計。
