from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
css = (ROOT / 'styles.css').read_text(encoding='utf-8')
js = (ROOT / 'app.js').read_text(encoding='utf-8')

# Test harness only: set_content has no persistent origin, so storage is bypassed.
js = js.replace("localStorage.getItem('farhp-theme') || 'dark'", "'dark'")
js = js.replace("localStorage.setItem('farhp-theme', root.dataset.theme);", "void 0;")
js = js.replace("document.addEventListener('DOMContentLoaded', init);", "init();")
html = html.replace('<link rel="stylesheet" href="styles.css">', f'<style>{css}</style>')
html = html.replace('<script src="app.js"></script>', f'<script>{js}</script>')

errors = []
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page(viewport={'width': 1440, 'height': 1200}, device_scale_factor=1)
    page.on('console', lambda msg: errors.append(f'console:{msg.type}:{msg.text}') if msg.type == 'error' else None)
    page.on('pageerror', lambda exc: errors.append(f'pageerror:{exc}'))
    page.set_content(html, wait_until='load')
    page.wait_for_timeout(500)

    assert page.locator('#initialSelect option').count() == 22
    assert page.locator('#finalSelect option').count() == 37
    assert page.locator('#syllableDisplay').inner_text() == 'ㄇㄚˇ'
    assert page.locator('#sequenceList .sequence-item').count() == 3
    assert page.locator('#utteranceLexical').inner_text() == 'ㄋㄧˇ　ㄏㄠˇ　˙ㄇㄚ'
    assert page.locator('#utteranceSurface').inner_text() == 'ㄋㄧˊ　ㄏㄠˇ　˙ㄇㄚ'

    page.select_option('#syllablePreset', 'xuan2')
    page.wait_for_timeout(100)
    assert page.locator('#syllableDisplay').inner_text() == 'ㄒㄩㄢˊ'
    assert '撮口呼' in page.locator('#metricSihu').inner_text()

    page.select_option('#syllablePreset', 'zhong1')
    page.wait_for_timeout(100)
    assert page.locator('#syllableDisplay').inner_text() == 'ㄓㄨㄥ'
    assert '/ŋ/' in page.locator('#metricCoda').inner_text()

    result = page.evaluate("""() => {
      const r = synthesizeSyllable();
      return {
        n: r.samples.length,
        min: r.f0Min,
        max: r.f0Max,
        finite: Array.from(r.samples.slice(0, 1000)).every(Number.isFinite),
        manifest: syllableManifest().phonology.bopomofo
      };
    }""")
    assert result['n'] > 10000
    assert result['finite']
    assert result['max'] >= result['min']
    assert result['manifest'] == 'ㄓㄨㄥ'

    page.select_option('#utterancePreset', 'wohenhao')
    page.wait_for_timeout(100)
    assert page.locator('#utteranceSurface').inner_text() == 'ㄨㄛˊ　ㄏㄣˊ　ㄏㄠˇ'
    assert '2 個三聲改寫' in page.locator('#utteranceRuleCertificate').inner_text()

    utterance_result = page.evaluate("""() => {
      const r = synthesizeUtterance();
      const m = utteranceManifest();
      return {n:r.samples.length, duration:r.duration, finite:Array.from(r.samples.slice(0,2000)).every(Number.isFinite), surface:m.surface_bopomofo};
    }""")
    assert utterance_result['n'] > 20000
    assert utterance_result['duration'] > 1
    assert utterance_result['finite']
    assert utterance_result['surface'] == ['ㄨㄛˊ','ㄏㄣˊ','ㄏㄠˇ']


    page.select_option('#utterancePreset', 'yitianbuqu')
    page.wait_for_timeout(100)
    assert page.locator('#utteranceSurface').inner_text() == 'ㄧˋ　ㄊㄧㄢ　ㄅㄨˊ　ㄑㄩˋ'
    assert '2 個一／不改寫' in page.locator('#utteranceRuleCertificate').inner_text()

    page.select_option('#utterancePreset', 'grouped')
    page.wait_for_timeout(100)
    assert page.locator('#utteranceSurface').inner_text() == 'ㄨㄛˊ　ㄏㄣˊ　ㄏㄠˇ　ㄋㄧˇ　˙ㄋㄜ'
    assert page.locator('#sequenceList .has-boundary').count() == 1
    grouped_result = page.evaluate("""() => {
      const r=synthesizeUtterance();
      return {groups:r.groupBoundaries.length,pause:r.groupBoundaries[0]?.pause_samples||0,left:r.realized[3].leftContextVowel,right:r.realized[2].rightContextVowel};
    }""")
    assert grouped_result['groups'] == 1
    assert grouped_result['pause'] > 2000
    assert grouped_result['left'] is None and grouped_result['right'] is None

    page.select_option('#utterancePreset', 'nihaoma')
    page.wait_for_timeout(100)
    question_final = page.evaluate("""() => { const r=synthesizeUtterance(); const a=Array.from(r.f0Track).filter(v=>v>0); return a.slice(-800).reduce((x,y)=>x+y,0)/Math.min(800,a.length); }""")
    page.select_option('#sentenceType', 'declarative')
    page.wait_for_timeout(100)
    declarative_final = page.evaluate("""() => { const r=synthesizeUtterance(); const a=Array.from(r.f0Track).filter(v=>v>0); return a.slice(-800).reduce((x,y)=>x+y,0)/Math.min(800,a.length); }""")
    assert question_final > declarative_final * 1.15

    page.click('#runShiftTest')
    assert 'PASS' in page.locator('#shiftResult').inner_text()

    # Build and finish a deterministic FARHP-only ABX session.
    page.evaluate("""() => { state.K=12; utteranceState.items=UTTERANCE_PRESETS.nihaoma.map(x=>({...normalizeUtteranceItem(x),duration:.24})); utteranceState.speechRate=1.55; updateUtteranceUI(); }""")
    page.locator('#experimentTrials').evaluate("el => { el.value='4'; el.dispatchEvent(new Event('input',{bubbles:true})); }")
    page.locator('#experimentStrength').evaluate("el => { el.value='0.75'; el.dispatchEvent(new Event('input',{bubbles:true})); }")
    page.fill('#experimentSeed', '424242')
    page.select_option('#experimentCondition', 'zero')
    page.click('#startExperimentBtn')
    page.wait_for_timeout(100)
    assert 'PASS' in page.locator('#experimentInvariant').inner_text()
    assert page.locator('#experimentProgress').inner_text() == '0 / 4'
    assert page.locator('#experimentAccuracy').inner_text() == '封存'
    assert page.locator('#experimentLog').inner_text().strip() == '尚無紀錄'

    experiment_info = page.evaluate("""() => {
      const session = experimentState.session;
      const mappings = session.trials.map(t => [t.a_condition,t.b_condition,t.x_condition,t.correct_answer]);
      while (!session.completed_at) {
        const t = currentExperimentTrial();
        t.play_counts = {A:1,B:1,X:1};
        t.started_at_ms = Date.now()-500;
        submitExperimentAnswer(t.correct_answer);
        advanceExperimentTrial();
      }
      const manifest = experimentManifest();
      return {
        version:manifest.farhp_weblab_experiment_version,
        trials:manifest.trials.length,
        accuracy:manifest.summary.accuracy,
        invariant:manifest.invariant_certificate.pass,
        mappings,
        csvLines:experimentCsv().split('\\n').length
      };
    }""")
    page.wait_for_timeout(100)
    assert experiment_info['version'] == '0.5'
    assert experiment_info['trials'] == 4
    assert experiment_info['accuracy'] == 1
    assert experiment_info['invariant'] is True
    assert experiment_info['csvLines'] == 5
    assert page.locator('#experimentAccuracy').inner_text() == '100%'
    assert page.locator('#experimentLog tr').count() == 4
    assert '隱藏' not in page.locator('#experimentLog').inner_text()
    assert page.locator('#experimentJsonBtn').is_enabled()
    assert page.locator('#experimentCsvBtn').is_enabled()

    page.screenshot(path=str(ROOT / 'assets' / 'preview_v0.5.png'), full_page=True)
    browser.close()

if errors:
    raise RuntimeError('\n'.join(errors))

print('FARHP WebLab browser test: PASS')
print(result)
print(utterance_result)
print(grouped_result)
print({'question_final_hz': question_final, 'declarative_final_hz': declarative_final})
print({'experiment': experiment_info, 'console_errors': len(errors)})
