# FARHP WebLab MVP v0.5

**基頻錨定相對諧波相位差 × 華語語流 × 可重複 ABX 盲聽實驗**

FARHP WebLab 是純前端、可離線執行的聲學研究原型。v0.5 延續華語音節、變調、韻律分組、句調與跨音節聲道插值，新增一個可重複的 ABX 盲聽實驗層。

網站不需要後端或 API Key。聲音、試驗隨機化、回答與匯出檔案都只在本機瀏覽器中處理。

## 使用方式

直接開啟 `index.html`。若瀏覽器限制本機檔案，可執行：

```bash
python -m http.server 8000
```

Windows 也可雙擊 `serve.bat`，再開啟：

```text
http://localhost:8000
```

## v0.5 核心流程

$$
\text{華語語流快照}
\rightarrow
\text{FARHP-only 基準／介入條件}
\rightarrow
\text{固定種子隨機化}
\rightarrow
\text{A／B／X 匿名播放}
\rightarrow
\text{回答與反應時間}
\rightarrow
\text{映射揭示與結果匯出}.
$$

實驗會固定：

- 詞典與表層注音；
- 三聲與「一／不」變調結果；
- 韻律分組與句調；
- 音節時長及邊界；
- 逐樣本基頻軌跡；
- 聲母、韻尾與聲道參數。

介入條件只改變 FARHP 來源與強度。

## ABX 實驗

每一輪包含：

- `A`：基準或介入條件之一；
- `B`：另一條件；
- `X`：與 `A` 或 `B` 完全相同；
- 使用者回答 `X = A` 或 `X = B`。

A／B 映射與正確性在整個實驗完成前保持封存。四種配置（基準在 A／B、X 為基準／介入）會先近似平衡，再依固定種子洗牌，降低位置偏差。完成後才揭示逐輪映射，並計算：

- 正確率；
- 反應時間中位數；
- 每個刺激播放次數；
- 額外重播總數。

### 可選介入條件

- 零相位；
- 奇偶交替相位；
- 固定隨機相位；
- 曲面相位。

介入強度為：

$$
\lambda\in[0.05,1].
$$

## 可重複性

實驗使用整數種子與 `mulberry32` 偽隨機生成器。相同語流、參數與種子會產生相同的：

- 隨機相位刺激；
- A／B 映射；
- X 條件序列。

結果 JSON 會保留種子、條件、映射、回答及不變量證書。

## 不變量證書

建立實驗時，網站會比較基準與介入刺激，檢查：

$$
\begin{aligned}
N_A&=N_B,\\
D_A&=D_B,\\
\max_n|f_{0,A}[n]-f_{0,B}[n]|&<10^{-9}\ \mathrm{Hz},\\
\text{Lexical}_A&=\text{Lexical}_B,\\
\text{Surface}_A&=\text{Surface}_B.
\end{aligned}
$$

同時要求波形 RMS 位移大於數值噪聲，避免建立「兩個實際相同刺激」的無效實驗。

## 匯出格式

- `farhp_abx_experiment.json`：完整實驗、隱藏映射、回答與統計；
- `farhp_abx_experiment.csv`：逐輪表格；
- 語流 WAV／JSON；
- 音節 WAV／JSON；
- 單框架 FARHP JSON。

JSON Schema：

- `spec/FARHP_Mandarin_Syllable_Spec_v0.5.schema.json`
- `spec/FARHP_Mandarin_Utterance_Spec_v0.5.schema.json`
- `spec/FARHP_ABX_Experiment_Spec_v0.5.schema.json`

## 範例

`examples/experiments/` 包含：

- 第一輪匿名 `A`、`B`、`X` WAV；
- 一份四輪 ABX 結果 JSON；
- 對應 CSV；
- 固定種子與不變量證書。

## 測試

```bash
node tests/selftest.cjs
python tests/browser_test.py
```

目前通過：

- 24 組 Node 數學、音系、合成與實驗回歸測試；
- Chromium 端到端操作測試；
- 13／13 範例 JSON Schema 驗證；
- 瀏覽器控制台零錯誤。

## 原有能力

- 22 種聲母選項，含零聲母；
- 37 種韻母／舌尖元音；
- 華語五聲連續 $$f_0(t)$$；
- 三聲與「一／不」變調；
- 語境輕聲；
- 韻律分組、組間停頓與句調；
- 跨音節共振包絡插值；
- 爆破、送氣、摩擦、鼻音與鼻韻尾殘差；
- FARHP 諧波合成、量化與逐諧波編輯；
- WAV 匯入、基頻估計與 FARHP 抽取；
- 時間平移不變性與 FARHP-only 證書。

## 目前邊界

本版本建立的是研究工具 MVP，不是完成的人類知覺研究：

- 目前只有單一瀏覽器使用者；
- 反覆使用同一合成語流，不能取代跨語者與跨語料設計；
- 未提供受試者招募、同意程序或匿名伺服器資料庫；
- 沒有信號檢測理論、功效分析與顯著性檢定；
- 合成聲音仍不是自然語音 TTS；
- 網站的盲化只封存 A／B 映射，不是完整雙盲臨床設計。

v0.5 證明的是：FARHP 已可進入**可重複、可盲化、可匯出、具條件證書的最小知覺實驗流程**。
