# FARHP WebLab MVP v0.4

**基頻錨定相對諧波相位差 × 華語韻律分組 × 句調 × 跨音節聲道插值**

FARHP WebLab 是純前端、可離線執行的互動聲學實驗站。v0.4 延續 v0.3 的多音節語流閉環，新增「一／不」變調、可編輯韻律邊界、組間停頓、陳述／疑問／感嘆句調，以及跨音節共振包絡插值。

網站不需要後端或 API Key；WAV、JSON 與分析結果都只在本機瀏覽器中處理。

## 使用方式

直接開啟 `index.html`。若瀏覽器限制本機檔案，可執行：

```bash
python -m http.server 8000
```

Windows 也可雙擊 `serve.bat`，再開啟：

```text
http://localhost:8000
```

## v0.4 核心流程

$$
\text{詞典音系}
\rightarrow
\text{韻律分組}
\rightarrow
\text{表層變調}
\rightarrow
\text{輕聲語境}
\rightarrow
\text{短語與句調}
\rightarrow
\text{聲道參數插值}
\rightarrow
\text{逐音節 FARHP}
\rightarrow
\text{邊界渲染}.
$$

這個順序保證聲調、韻律、聲道與 FARHP 不被合併成單一不透明參數。

## 新增功能

### 「一／不」變調

目前採用可檢驗的局部表層規則：

$$
\text{一} + T_4 \rightarrow T_2 + T_4,
$$

$$
\text{一} + T_{1,2,3} \rightarrow T_4 + T_{1,2,3},
$$

$$
\text{不} + T_4 \rightarrow T_2 + T_4.
$$

「一／不」變調與三聲變調分別記錄，JSON 中會保留 `sandhi_types`、`third_tone_sandhi` 與 `yi_bu_sandhi`。

### 韻律分組

音節序列中的「｜」按鈕可切換組末邊界。邊界會：

- 阻斷跨組三聲與「一／不」變調；
- 重設短語級基頻下傾；
- 停止跨邊界聲道插值；
- 停止音訊交疊；
- 插入可調整的無聲停頓；
- 對組末音節施加延長。

### 句調

支援：

- `declarative`：句末微降；
- `question`：句末上揚；
- `exclamation`：高起急降。

句調以獨立半音偏移軌跡加入聲調：

$$
f_0(t)
=
f_{0,\mathrm{base}}
2^{\frac{T(t)+I(t)}{12}},
$$

其中 $T(t)$ 是詞彙／表層聲調，$I(t)$ 是句調軌跡。

### 跨音節聲道參數插值

v0.3 只有音訊邊界交疊；v0.4 會在組內音節首尾，將相鄰母音的共振包絡混入目前音節：

$$
E_k(t)
=
(1-\alpha(t))E_k^{\mathrm{current}}
+
\alpha(t)E_k^{\mathrm{context}}.
$$

它仍是簡化的頻譜包絡模型，不是完整聲道面積函數或生理發音模型。

## 內建語流

- 你好；
- 你好嗎；
- 我很好；
- 媽媽好；
- 一個不好嗎；
- 一天不去；
- 我很好｜你呢。

`examples/utterances/` 內含七組 WAV 與 JSON。

## 原有能力

- 22 種聲母選項，含零聲母；
- 37 種韻母／舌尖元音；
- 四呼類別檢查；
- 華語五聲連續 $f_0(t)$；
- 爆破、送氣、塞擦、摩擦、鼻音與鼻韻尾殘差；
- FARHP 諧波合成與逐諧波編輯；
- 8、16、32、64 相量化；
- WAV 匯入、基頻估計與 FARHP 抽取；
- 時間平移不變性與 FARHP-only 證書；
- 音節及語流 WAV／JSON 匯出。

## 測試

```bash
node tests/selftest.cjs
python tests/browser_test.py
```

目前包含 19 組 Node 回歸測試，以及 Chromium 端到端測試。涵蓋：

- FARHP 時間平移不變性；
- 相位量化誤差界；
- 華語五聲輪廓；
- 四呼類別檢查；
- 三聲變調；
- 「一／不」變調；
- 韻律邊界阻斷；
- 組間無聲停頓；
- 疑問句與陳述句句尾差異；
- 聲道插值造成波形改變但保持 $f_0$ 軌跡；
- WAV RIFF／WAVE 格式。

## JSON Schema

- `spec/FARHP_Mandarin_Syllable_Spec_v0.3.schema.json`
- `spec/FARHP_Mandarin_Utterance_Spec_v0.4.schema.json`

七份 v0.4 語流示範 JSON 均已通過 Draft 2020-12 Schema 驗證。

## 目前邊界

本版本仍是結構型聲學 MVP，而非自然語音 TTS：

- 韻律組由人工邊界指定，尚未自動解析句法；
- 「一／不」規則尚未處理序數、孤立讀法及詞彙例外；
- 句調使用參數化曲線，未從自然語料學習；
- 聲道插值只是共振包絡過渡，不是連續聲道物理模型；
- 擦音、塞音與送氣仍採殘差代理；
- 尚未進行大規模自然語料與人類盲聽驗證。

v0.4 證明的是：FARHP 能在保持自身相位子系統邊界的前提下，與華語變調、韻律分組、句調及聲道過渡共同工作。
