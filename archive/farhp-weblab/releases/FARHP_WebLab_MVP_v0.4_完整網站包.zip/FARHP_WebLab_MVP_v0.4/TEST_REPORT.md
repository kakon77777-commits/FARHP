# FARHP WebLab MVP v0.4 測試報告

## 測試範圍

本報告驗證 v0.4 的四個新增層：

$$
\text{一／不變調}
+
\text{韻律分組}
+
\text{句調}
+
\text{跨音節聲道插值}.
$$

同時保留 v0.1–v0.3 的 FARHP 相位、量化、華語五聲、音節合成及多音節回歸測試。

## 執行環境

- 純前端 HTML／CSS／JavaScript；
- 取樣率：$$24{,}000\ \mathrm{Hz}$$；
- Node 自測：`node tests/selftest.cjs`；
- Chromium 端到端測試：`python tests/browser_test.py`；
- JSON Schema：Draft 2020-12。

## 結果摘要

| 項目 | 結果 |
|---|---:|
| JavaScript 語法 | PASS |
| Node 回歸測試 | 19 組 PASS |
| Chromium 端到端測試 | PASS |
| 瀏覽器控制台錯誤 | 0 |
| v0.4 語流 JSON Schema | 7／7 PASS |
| 聲母選項 | 22 |
| 韻母／舌尖元音 | 37 |
| 語流示範 | 7 組 WAV／JSON |

## 規則測試

### 三聲變調

「我很好」的詞典聲調為：

$$
3,3,3,
$$

未指定內部韻律邊界時，表層輸出為：

$$
2,2,3.
$$

### 「一／不」變調

「一天不去」的詞典聲調為：

$$
1,1,4,4.
$$

表層輸出為：

$$
4,1,2,4,
$$

即：

```text
ㄧˋ　ㄊㄧㄢ　ㄅㄨˊ　ㄑㄩˋ
```

「一個不好嗎」的「一」在第四聲前改為第二聲；「不」在第三聲前維持第四聲。兩種改寫會分別標記為 `一變調` 與 `不變調`。

### 韻律分組

「我很好｜你呢」建立兩個韻律組：

$$
[3,3,3]\mid[3,0]
\rightarrow
[2,2,3]\mid[3,0].
$$

邊界阻止第三個第三聲與下一組第一個第三聲發生跨組變調。

組間停頓設定為：

$$
90\ \mathrm{ms},
$$

在 $$24{,}000\ \mathrm{Hz}$$ 下對應：

$$
2{,}160\ \text{samples}.
$$

測試確認該區段的音訊及基頻軌跡都為零，且邊界兩側的聲道上下文被清除。

## 句調測試

同一組「你好嗎」在疑問句與陳述句模式下，最後約 800 個有聲樣本的平均基頻為：

| 句型 | 句尾平均基頻 |
|---|---:|
| 疑問句 | $$173.843\ \mathrm{Hz}$$ |
| 陳述句 | $$126.845\ \mathrm{Hz}$$ |

比值約為：

$$
\frac{173.843}{126.845}
\approx
1.371.
$$

因此句型控制確實進入合成基頻軌跡，而不是只改變介面標籤。

## 跨音節聲道插值測試

測試固定：

- 音節序列；
- 詞典與表層聲調；
- $$f_0(t)$$；
- FARHP 相位來源；
- 音訊交疊設定。

只切換共振包絡插值。結果：

- 波形 RMS 差大於 $$10^{-4}$$；
- 兩組 $$f_0$$ 軌跡逐樣本完全一致；
- 韻律邊界兩側的上下文母音為 `null`；
- 組內音節具有左／右相鄰母音上下文。

這證明該控制改變的是聲道頻譜包絡，而不是偷偷改寫聲調或 FARHP。

## FARHP 回歸測試

共同時間平移後的 FARHP 最大誤差仍在數值精度範圍內；相位量化誤差維持：

$$
d_{S^1}(\psi,Q_M(\psi))
\le
\frac{\pi}{M}.
$$

WAV 寫出器仍通過 `RIFF`、`WAVE` 與 `data` 標頭驗證。

## Schema 驗證

下列七份 JSON 均通過：

- `nihao.json`；
- `nihaoma.json`；
- `wohenhao.json`；
- `mamahao.json`；
- `yigebuhaoma.json`；
- `yitianbuqu.json`；
- `grouped.json`。

使用規格：

```text
spec/FARHP_Mandarin_Utterance_Spec_v0.4.schema.json
```

## 結論與限制

v0.4 已建立可執行的分層閉環：

$$
\boxed{
\text{詞典音系}
\rightarrow
\text{韻律組}
\rightarrow
\text{變調}
\rightarrow
\text{句調}
\rightarrow
\text{聲道插值}
\rightarrow
\text{FARHP}
\rightarrow
\text{聲波}
}
$$

它證明各層可以共同運作並留下交換證書，但不代表：

- 已完成自然語言句法分析；
- 已覆蓋全部「一／不」詞彙例外；
- 已建立生理精確的聲道模型；
- 已達到自然語音 TTS 品質；
- 已通過大規模人類知覺實驗。
