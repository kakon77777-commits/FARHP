from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
css = (ROOT / 'styles.css').read_text(encoding='utf-8')
js = (ROOT / 'app.js').read_text(encoding='utf-8')

# Test harness only: set_content has no persistent origin, so storage is bypassed.
js = js.replace("localStorage.getItem('farhp-theme') || 'dark'", "'dark'")
js = js.replace("localStorage.setItem('farhp-theme', root.dataset.theme);", "void 0;")
js = js.replace("document.addEventListener('DOMContentLoaded', init);", "init();")
html = html.replace('<link rel="stylesheet" href="styles.css">', f'<style>{css}</style>')
html = html.replace('<script src="app.js"></script>', f'<script>{js}</script>')

errors = []
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page(viewport={'width': 1440, 'height': 1200}, device_scale_factor=1)
    page.on('console', lambda msg: errors.append(f'console:{msg.type}:{msg.text}') if msg.type == 'error' else None)
    page.on('pageerror', lambda exc: errors.append(f'pageerror:{exc}'))
    page.set_content(html, wait_until='load')
    page.wait_for_timeout(500)

    assert page.locator('#initialSelect option').count() == 22
    assert page.locator('#finalSelect option').count() == 37
    assert page.locator('#syllableDisplay').inner_text() == 'ㄇㄚˇ'
    assert page.locator('#sequenceList .sequence-item').count() == 3
    assert page.locator('#utteranceLexical').inner_text() == 'ㄋㄧˇ　ㄏㄠˇ　˙ㄇㄚ'
    assert page.locator('#utteranceSurface').inner_text() == 'ㄋㄧˊ　ㄏㄠˇ　˙ㄇㄚ'

    page.select_option('#syllablePreset', 'xuan2')
    page.wait_for_timeout(100)
    assert page.locator('#syllableDisplay').inner_text() == 'ㄒㄩㄢˊ'
    assert '撮口呼' in page.locator('#metricSihu').inner_text()

    page.select_option('#syllablePreset', 'zhong1')
    page.wait_for_timeout(100)
    assert page.locator('#syllableDisplay').inner_text() == 'ㄓㄨㄥ'
    assert '/ŋ/' in page.locator('#metricCoda').inner_text()

    result = page.evaluate("""() => {
      const r = synthesizeSyllable();
      return {
        n: r.samples.length,
        min: r.f0Min,
        max: r.f0Max,
        finite: Array.from(r.samples.slice(0, 1000)).every(Number.isFinite),
        manifest: syllableManifest().phonology.bopomofo
      };
    }""")
    assert result['n'] > 10000
    assert result['finite']
    assert result['max'] >= result['min']
    assert result['manifest'] == 'ㄓㄨㄥ'

    page.select_option('#utterancePreset', 'wohenhao')
    page.wait_for_timeout(100)
    assert page.locator('#utteranceSurface').inner_text() == 'ㄨㄛˊ　ㄏㄣˊ　ㄏㄠˇ'
    assert '2 個三聲改寫' in page.locator('#utteranceRuleCertificate').inner_text()

    utterance_result = page.evaluate("""() => {
      const r = synthesizeUtterance();
      const m = utteranceManifest();
      return {n:r.samples.length, duration:r.duration, finite:Array.from(r.samples.slice(0,2000)).every(Number.isFinite), surface:m.surface_bopomofo};
    }""")
    assert utterance_result['n'] > 20000
    assert utterance_result['duration'] > 1
    assert utterance_result['finite']
    assert utterance_result['surface'] == ['ㄨㄛˊ','ㄏㄣˊ','ㄏㄠˇ']


    page.select_option('#utterancePreset', 'yitianbuqu')
    page.wait_for_timeout(100)
    assert page.locator('#utteranceSurface').inner_text() == 'ㄧˋ　ㄊㄧㄢ　ㄅㄨˊ　ㄑㄩˋ'
    assert '2 個一／不改寫' in page.locator('#utteranceRuleCertificate').inner_text()

    page.select_option('#utterancePreset', 'grouped')
    page.wait_for_timeout(100)
    assert page.locator('#utteranceSurface').inner_text() == 'ㄨㄛˊ　ㄏㄣˊ　ㄏㄠˇ　ㄋㄧˇ　˙ㄋㄜ'
    assert page.locator('#sequenceList .has-boundary').count() == 1
    grouped_result = page.evaluate("""() => {
      const r=synthesizeUtterance();
      return {groups:r.groupBoundaries.length,pause:r.groupBoundaries[0]?.pause_samples||0,left:r.realized[3].leftContextVowel,right:r.realized[2].rightContextVowel};
    }""")
    assert grouped_result['groups'] == 1
    assert grouped_result['pause'] > 2000
    assert grouped_result['left'] is None and grouped_result['right'] is None

    page.select_option('#utterancePreset', 'nihaoma')
    page.wait_for_timeout(100)
    question_final = page.evaluate("""() => { const r=synthesizeUtterance(); const a=Array.from(r.f0Track).filter(v=>v>0); return a.slice(-800).reduce((x,y)=>x+y,0)/Math.min(800,a.length); }""")
    page.select_option('#sentenceType', 'declarative')
    page.wait_for_timeout(100)
    declarative_final = page.evaluate("""() => { const r=synthesizeUtterance(); const a=Array.from(r.f0Track).filter(v=>v>0); return a.slice(-800).reduce((x,y)=>x+y,0)/Math.min(800,a.length); }""")
    assert question_final > declarative_final * 1.15

    page.click('#runShiftTest')
    assert 'PASS' in page.locator('#shiftResult').inner_text()

    # Build and finish a deterministic multi-stimulus study with practice and a rest node.
    page.evaluate("""() => { state.K=6; syllableState.duration=.12; utteranceState.speechRate=2.0; }""")
    page.locator('#stimulusPool input').evaluate_all("els => els.forEach(el => { el.checked = ['nihao','nihaoma'].includes(el.value); })")
    page.fill('#studyId', 'TEST-STUDY')
    page.fill('#participantId', 'P-BROWSER')
    page.locator('#studyRepeats').evaluate("el => { el.value='1'; el.dispatchEvent(new Event('input',{bubbles:true})); }")
    page.select_option('#practiceTrials', '1')
    page.select_option('#breakEvery', '1')
    page.locator('#experimentStrength').evaluate("el => { el.value='0.75'; el.dispatchEvent(new Event('input',{bubbles:true})); }")
    page.fill('#experimentSeed', '424242')
    page.select_option('#experimentCondition', 'zero')
    page.click('#startExperimentBtn')
    page.wait_for_timeout(500)
    assert 'PASS' in page.locator('#experimentInvariant').inner_text()
    assert page.locator('#experimentProgress').inner_text() == '0 / 2'
    assert '練習' in page.locator('#experimentPhase').inner_text()
    assert page.locator('#experimentAccuracy').inner_text() == '封存'

    study_result = page.evaluate("""() => {
      const session=experimentState.session;
      const practice=currentExperimentTrial();
      practice.play_counts={A:1,B:1,X:1}; practice.started_at_ms=Date.now()-400;
      submitExperimentAnswer(practice.correct_answer);
      const practiceFeedback=document.querySelector('#experimentFeedback').textContent;
      advanceExperimentTrial();
      const first=currentExperimentTrial();
      first.play_counts={A:1,B:1,X:1}; first.started_at_ms=Date.now()-600;
      submitExperimentAnswer(first.correct_answer);
      advanceExperimentTrial();
      const breakTriggered=session.on_break;
      advanceExperimentTrial();
      const second=currentExperimentTrial();
      second.play_counts={A:1,B:1,X:1}; second.started_at_ms=Date.now()-800;
      submitExperimentAnswer(second.correct_answer==='A'?'B':'A');
      advanceExperimentTrial();
      const manifest=experimentManifest();
      const clone=JSON.parse(JSON.stringify(manifest)); clone.participant_id='P-BROWSER-2'; clone.session_id+='-2';
      for(const t of clone.trials){if(!t.is_practice&&t.response)t.response.correct=true;}
      const group=mergeStudyManifests([manifest,clone]); experimentState.groupAnalysis=group; renderGroupAnalysis();
      return {
        version:manifest.farhp_weblab_study_version,
        totalTrials:manifest.trials.length,
        mainTrials:manifest.summary.answered_main_trials,
        practice:manifest.summary.practice_answered,
        accuracy:manifest.summary.main_accuracy,
        invariant:manifest.invariant_certificates.every(x=>x.pass),
        breakTriggered,
        practiceFeedback,
        groupParticipants:group.participant_count,
        groupTrials:group.main_trials,
        groupAccuracy:group.accuracy,
        csvLines:experimentCsv().split('\\n').length,
      };
    }""")
    page.wait_for_timeout(100)
    assert study_result['version'] == '0.6'
    assert study_result['totalTrials'] == 3
    assert study_result['mainTrials'] == 2
    assert study_result['practice'] == 1
    assert study_result['accuracy'] == 0.5
    assert study_result['invariant'] is True
    assert study_result['breakTriggered'] is True
    assert '練習回饋' in study_result['practiceFeedback']
    assert study_result['groupParticipants'] == 2
    assert study_result['groupTrials'] == 4
    assert study_result['groupAccuracy'] == 0.75
    assert study_result['csvLines'] == 4
    assert page.locator('#experimentAccuracy').inner_text() == '50%'
    assert page.locator('#experimentLog tr').count() == 3
    assert '隱藏' not in page.locator('#experimentLog').inner_text()
    assert page.locator('#experimentJsonBtn').is_enabled()
    assert page.locator('#experimentCsvBtn').is_enabled()
    assert page.locator('#groupParticipants').inner_text() == '2'
    assert page.locator('#groupTrials').inner_text() == '4'
    assert page.locator('#groupJsonBtn').is_enabled()
    assert page.locator('#groupCsvBtn').is_enabled()

    page.screenshot(path=str(ROOT / 'assets' / 'preview_v0.6.png'), full_page=True)
    browser.close()

if errors:
    raise RuntimeError('\n'.join(errors))

print('FARHP WebLab browser test: PASS')
print(result)
print(utterance_result)
print(grouped_result)
print({'question_final_hz': question_final, 'declarative_final_hz': declarative_final})
print({'study': study_result, 'console_errors': len(errors)})
