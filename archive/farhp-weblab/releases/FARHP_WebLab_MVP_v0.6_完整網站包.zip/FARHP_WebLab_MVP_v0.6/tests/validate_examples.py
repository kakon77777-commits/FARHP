from pathlib import Path
import json
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
CASES = [
    (ROOT / 'spec/FARHP_MultiStimulus_Study_Spec_v0.6.schema.json', sorted((ROOT / 'examples/study_v0.6').glob('study_*.json'))),
    (ROOT / 'spec/FARHP_Group_Analysis_Spec_v0.6.schema.json', [ROOT / 'examples/study_v0.6/group_analysis.json']),
]
count = 0
for schema_path, files in CASES:
    validator = Draft202012Validator(json.loads(schema_path.read_text(encoding='utf-8')))
    for file_path in files:
        errors = sorted(validator.iter_errors(json.loads(file_path.read_text(encoding='utf-8'))), key=lambda e: list(e.path))
        if errors:
            raise AssertionError(f'{file_path.name}: {errors[0].message}')
        print(f'PASS {file_path.name}')
        count += 1
print(f'FARHP WebLab schema validation: {count} files PASS')
