# FARHP WebLab v0.6 資料字典

## Study JSON

| 欄位 | 說明 |
|---|---|
| `study_id` | 研究代碼 |
| `participant_id` | 匿名受試者代碼 |
| `session_id` | 單次研究工作階段唯一 ID |
| `setup.selected_stimuli` | 納入的刺激鍵 |
| `setup.participant_latin_row` | 受試者刺激順序列索引 |
| `trials[].is_practice` | 是否為練習輪 |
| `trials[].stimulus_key` | 本輪刺激 |
| `a_condition`／`b_condition`／`x_condition` | 匿名刺激的實際條件 |
| `response.answer` | 受試者回答 A 或 B |
| `response.correct` | 是否正確 |
| `response.rt_ms` | 自第一次播放起算的反應時間 |
| `play_counts` | A、B、X 播放次數 |
| `summary.main_accuracy` | 排除練習輪的正式正確率 |

## Group JSON

| 欄位 | 說明 |
|---|---|
| `source_files` | 去重後有效工作階段數 |
| `duplicate_sessions_ignored` | 被忽略的重複或無效檔案數 |
| `participant_count` | `study_id + participant_id` 唯一組合數 |
| `main_trials` | 有回答的正式輪總數 |
| `accuracy` | pooled accuracy |
| `wilson_95` | 95% Wilson 區間 |
| `binomial_two_sided_p` | 對 50% 機率基準的雙側二項檢定 |
| `by_condition_and_stimulus` | 介入條件與刺激分組摘要 |
