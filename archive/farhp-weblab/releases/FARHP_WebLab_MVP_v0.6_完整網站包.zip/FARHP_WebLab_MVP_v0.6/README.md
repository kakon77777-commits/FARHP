# FARHP WebLab MVP v0.6

FARHP WebLab 是「基頻錨定相對諧波相位差」的離線互動研究網站。v0.6 在既有華語音節、語流、韻律與單刺激 ABX 基礎上，新增多刺激知覺研究流程、匿名受試者順序配置、練習／休息節點與群體資料合併。

## 快速啟動

直接開啟 `index.html` 即可。若瀏覽器限制本機檔案：

```bash
python -m http.server 8000
```

或執行：

- Windows：`serve.bat`
- Linux／macOS：`bash serve.sh`

再開啟 `http://localhost:8000`。

## v0.6 主要功能

### 多刺激 ABX 研究

- 內建 7 組華語語流刺激；
- 可任選至少 2 組形成刺激池；
- 每刺激可重複 1–3 次；
- 以匿名受試者 ID 決定刺激順序列；
- ABX 四種條件配置近似平衡；
- 正式輪完成前封存正確答案及 A／B 映射。

### 研究流程控制

- 匿名研究 ID 與受試者 ID；
- 0–4 次練習輪；
- 練習輪即時回饋且不納入正式正確率；
- 可設定固定正式輪休息節點；
- 每輪記錄回答、反應時間與 A／B／X 播放次數；
- 完成後輸出研究 JSON 與逐輪 CSV。

### FARHP-only 刺激證書

每一組刺激均檢查：

$$
N_0=N_1,
$$

$$
D_0=D_1,
$$

$$
\max_n\left|f_{0,0}[n]-f_{0,1}[n]\right|<10^{-9}\ \mathrm{Hz},
$$

以及詞典注音、表層注音相同，且波形確實發生非零改變。

### 群體資料合併

可一次匯入多份 v0.6 研究 JSON，於本機計算：

- 有效研究檔案數；
- 匿名受試者數；
- 正式輪總數與正確率；
- 95% Wilson 信賴區間；
- 相對 50% 機率基準的雙側二項檢定；
- 依介入條件與刺激分組的正確率及中位反應時間；
- 群體 JSON 與 CSV。

重複 `session_id` 會被忽略，避免同一份檔案重複計數。

## 研究資料與規格

- `spec/FARHP_MultiStimulus_Study_Spec_v0.6.schema.json`
- `spec/FARHP_Group_Analysis_Spec_v0.6.schema.json`
- `spec/FARHP_Mandarin_Syllable_Spec_v0.6.schema.json`
- `spec/FARHP_Mandarin_Utterance_Spec_v0.6.schema.json`
- `examples/study_v0.6/`：模擬受試者與群體合併範例。

## 測試

```bash
node tests/selftest.cjs
python tests/browser_test.py
python tests/validate_examples.py
```

最終結果：

- Node：30 組測試通過；
- Chromium：完整端到端流程通過；
- 控制台錯誤：0；
- v0.6 Study Schema：3／3 通過；
- v0.6 Group Schema：1／1 通過。

## 研究邊界

此網站是離線聲學與知覺研究 MVP，不是：

- 真人級自然語音 TTS；
- 正式招募或受試者管理平台；
- IRB／研究倫理審查替代品；
- 具伺服器端權限、加密及資料治理的臨床或商業研究系統；
- FARHP 人類知覺效果已成立的證明。

請勿在匿名受試者 ID 欄位輸入姓名、Email、電話或其他可識別資料。
