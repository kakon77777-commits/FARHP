# FARHP WebLab MVP v0.2

**基頻錨定相對諧波相位差 × 華語相位音節合成器**

這是一個純前端、可離線執行的 FARHP 互動網站。v0.2 在原有的諧波相位實驗台、WAV 單框架分析與不變性驗證之外，新增華語注音音節的分層合成工作流。

## 直接使用

解壓縮後開啟 `index.html`。若瀏覽器限制本機檔案，可執行：

```bash
python -m http.server 8000
```

或在 Windows 雙擊 `serve.bat`，再開啟：

```text
http://localhost:8000
```

網站不需要後端、不需要 API Key，音訊只在瀏覽器本機處理。

## v0.2 新增功能

### 華語相位音節合成器

- 22 種聲母選項，含零聲母；
- 37 種韻母／舌尖元音選項；
- 開口呼、齊齒呼、合口呼、撮口呼與舌尖元音類別檢查；
- 第一聲、第二聲、第三聲、第四聲與輕聲；
- 連續基頻軌跡 $f_0(t)$；
- 聲母爆破、送氣、塞擦、摩擦、鼻音、邊音與近音插槽；
- 前鼻音、後鼻音與兒化尾段模型；
- FARHP 來源切換：實驗台、零相位、曲面、奇偶交替、固定隨機；
- 即時波形與聲調軌跡；
- WAV 與音節 JSON 匯出；
- 音節核心送回 FARHP 實驗台。

### 分層模型

華語音節被表示為：

$$
\Sigma
=
(O,F,T,D,\boldsymbol\Psi,R),
$$

其中：

- $O$：聲母與起音模型；
- $F$：韻母、四呼與韻尾；
- $T$：聲調及 $f_0(t)$；
- $D$：時長；
- $\boldsymbol\Psi$：FARHP 相對諧波相位；
- $R$：爆破、送氣、摩擦與鼻尾殘差。

合成時維持：

$$
\text{聲調}\neq\text{FARHP},
$$

即聲調仍由 $f_0(t)$ 控制，FARHP 只改變週期內諧波相對位置。

## 原有功能

- FARHP 諧波合成；
- 振幅與相位逐諧波編輯；
- 8、16、32、64 相量化；
- 波形、頻譜與相位輪；
- WAV 匯入、基頻估計與相位抽取；
- 時間平移不變性測試；
- 量化誤差界測試；
- FARHP-only 不變量證書；
- WAV、分析 JSON 與 FARHP JSON 匯出。

## 範例

`examples/mandarin_tones/` 內含「ㄇㄚ」五聲的 WAV 與 JSON：

```text
ma_tone1.wav / .json
ma_tone2.wav / .json
ma_tone3.wav / .json
ma_tone4.wav / .json
ma_tone0.wav / .json
```

重新產生範例：

```bash
node tools/generate_examples.cjs
```

## 測試

```bash
node tests/selftest.cjs
python tests/browser_test.py
```

Node 自測涵蓋九組：

1. 相位包覆與圓周距離；
2. 相位量化誤差界；
3. 時間平移不變性；
4. 合成—基頻估計閉環；
5. 五聲輪廓；
6. 四呼類別檢查；
7. 動態音節波形；
8. 音節分層 JSON；
9. WAV 標頭。

瀏覽器測試會檢查初始「ㄇㄚˇ」、撮口呼「ㄒㄩㄢˊ」、後鼻音「ㄓㄨㄥ」、動態合成、manifest 與原 FARHP 不變性測試。

## JSON Schema

音節匯出格式位於：

```text
spec/FARHP_Mandarin_Syllable_Spec_v0.2.schema.json
```

五個示範 JSON 均已通過 Schema 驗證。

## 目前邊界

本版本是**聲學結構與控制介面的 MVP**，不是自然語音 TTS。尚未完成：

- 真實語料訓練；
- 高品質聲門源與聲道逆濾波；
- 精確共構音；
- 變調、輕聲語境與句子韻律；
- 完整合法華語音節詞彙表；
- 人類盲聽與語音學標註驗證；
- 跨框架自然語音聲碼器。

聲母—四呼檢查目前是音系類別層級，而非逐字典音節授權表；因此「可合成」不等於該組合一定是現代標準華語中的常用音節。
