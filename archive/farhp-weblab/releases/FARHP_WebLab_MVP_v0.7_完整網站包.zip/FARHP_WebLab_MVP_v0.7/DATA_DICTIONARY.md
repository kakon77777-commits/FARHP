# FARHP WebLab v0.7 資料字典

## Research Plan JSON

| 欄位 | 說明 |
|---|---|
| `farhp_weblab_plan_version` | 研究計畫規格版本，目前為 `0.7` |
| `study_id` | 研究代碼 |
| `planned_sample_size` | 計畫受試者數 |
| `primary_endpoint` | 事前指定的主要終點 |
| `preregistration_note` | 設計備註或外部預註冊索引 |
| `design.selected_stimuli` | 刺激鍵陣列 |
| `design.altered_condition` | FARHP 介入條件 |
| `design.intervention_strength` | 介入強度 $\lambda$ |
| `design.seed` | 可重複研究種子 |
| `exclusion_policy` | 事前排除政策 |
| `status` | `draft` 或 `locked` |
| `plan_fingerprint.algorithm` | `SHA-256` 或明確標記的備援算法 |
| `plan_fingerprint.value` | 64 字元十六進位指紋 |

## Session Checkpoint JSON

| 欄位 | 說明 |
|---|---|
| `farhp_weblab_checkpoint_version` | 檢查點規格版本 |
| `saved_at` | 保存時間 |
| `plan` | 完整鎖定研究計畫 |
| `session.session_id` | 工作階段唯一代碼 |
| `session.current_index` | 當前試驗索引 |
| `session.on_break` | 是否位於休息節點 |
| `session.break_count` | 已觸發休息數 |
| `session.trials[].play_counts` | A／B／X 播放次數 |
| `session.trials[].response` | 已提交回答、反應時間與時間戳 |
| `privacy_note` | 明示不包含音訊陣列與直接識別資料 |

## Study JSON

| 欄位 | 說明 |
|---|---|
| `farhp_weblab_study_version` | 單人研究規格版本 |
| `session_id` | 單次研究工作階段唯一 ID |
| `study_id` | 研究代碼 |
| `participant_id` | 匿名受試者代碼 |
| `plan_fingerprint` | 建立本工作階段時使用的計畫指紋 |
| `plan` | 完整鎖定計畫快照 |
| `setup.selected_stimuli` | 納入刺激鍵 |
| `invariant_certificates` | 每個刺激的 FARHP-only 證書 |
| `trials[].is_practice` | 是否為練習輪 |
| `trials[].stimulus_key` | 本輪刺激 |
| `trials[].a_condition`／`b_condition`／`x_condition` | 真實條件，僅於完成後揭示 |
| `trials[].response.answer` | 受試者回答 A 或 B |
| `trials[].response.correct` | 是否正確 |
| `trials[].response.rt_ms` | 反應時間 |
| `trials[].play_counts` | A／B／X 播放次數 |
| `trial_exclusion_certificates` | 試驗級有效性與排除原因 |
| `session_exclusion_certificate` | 工作階段級納入狀態與理由 |
| `summary.main_accuracy` | 有效正式輪正確率 |

## Group JSON

| 欄位 | 說明 |
|---|---|
| `farhp_weblab_group_version` | 群體分析版本 |
| `source_files` | 去重後有效匯入工作階段數 |
| `included_sessions` | 納入工作階段數 |
| `excluded_sessions` | 排除工作階段數 |
| `excluded_session_log` | 排除原因與比例稽核紀錄 |
| `participant_count` | 至少有一個納入工作階段的匿名受試者數 |
| `all_participant_count` | 納入與排除受試者總數 |
| `main_trials` | 納入的有效正式輪數 |
| `excluded_trials` | 排除正式輪數 |
| `accuracy` | pooled accuracy |
| `wilson_95` | 95% Wilson 區間 |
| `binomial_two_sided_p` | 對 50% 機率基準的雙側二項檢定 |
| `by_participant` | 受試者層描述摘要 |
| `by_stimulus` | 刺激層描述摘要 |
| `by_condition_and_stimulus` | 條件 × 刺激描述摘要 |

## 相容性

v0.7 群體分析器可讀取 v0.6 Study JSON。舊資料若沒有鎖定排除政策，會採相容模式處理並保留其原始欄位；不應在匯入後憑觀察到的正確率追加排除。
