# FARHP WebLab MVP v0.7

FARHP WebLab 是「基頻錨定相對諧波相位差」的離線互動聲學與知覺研究網站。v0.7 在 v0.6 多刺激 ABX 研究流程上，新增可鎖定的研究計畫、計畫指紋、工作階段檢查點、中斷恢復、事前排除規則，以及受試者／刺激兩層描述統計。

## 快速啟動

直接開啟 `index.html` 即可。若瀏覽器限制本機檔案，建議啟動本機 HTTP 服務：

```bash
python -m http.server 8000
```

或執行：

- Windows：`serve.bat`
- Linux／macOS：`bash serve.sh`

再開啟 `http://localhost:8000`。

## v0.7 主要功能

### 研究計畫與設定鎖定

研究者可以先建立完整計畫，包含：

- `study_id`；
- 刺激池；
- FARHP 介入條件與強度；
- 每刺激重複數；
- 練習輪與休息節點；
- 固定種子；
- 計畫樣本數；
- 主要終點；
- 預註冊備註；
- 事前排除政策。

鎖定後，網站會生成 64 個十六進位字元的計畫指紋，並凍結會改變研究設計的控制項。可匯出／匯入計畫 JSON，也可以把鎖定計畫複製成新的可編輯草稿。

在支援 Web Crypto 的瀏覽器來源中，計畫指紋使用 SHA-256；若執行環境不提供 Web Crypto，則使用明確標記為 `FNV32x8-fallback` 的確定性備援，不會把備援值冒充成 SHA-256。

### 輕量工作階段檢查點

正式研究每輪回答、休息節點與狀態變更後，都可建立輕量檢查點。檢查點保存：

- 鎖定研究計畫；
- 匿名受試者與工作階段代碼；
- 當前輪次；
- 回答與反應時間；
- A／B／X 播放次數；
- 休息節點狀態。

檢查點**不保存音訊陣列**。恢復時依計畫、刺激與固定種子重新生成聲音，避免將大型音訊寫入瀏覽器儲存空間。

可使用：

- 瀏覽器本機自動檢查點；
- 檢查點 JSON 匯出；
- 檢查點 JSON 匯入；
- 重新載入後恢復研究。

### 事前排除政策

v0.7 可在鎖定前固定：

- 最小反應時間；
- 最大反應時間；
- 最低完成比例；
- 最低有效試驗比例；
- A／B／X 每一標籤最低播放次數。

排除只依程序品質判定，明確禁止依正確率排除：

```text
accuracy_based_exclusion = false
```

群體資料合併時，網站會輸出試驗級與工作階段級排除證書，保留原因、完成比例與有效試驗比例。

### 受試者與刺激階層摘要

群體分析新增：

- 納入／排除工作階段數；
- 納入／排除試驗數；
- pooled accuracy；
- 95% Wilson 信賴區間；
- 相對 50% 機率基準的雙側二項檢定；
- 受試者層摘要；
- 刺激層摘要；
- 條件 × 刺激摘要；
- 排除工作階段稽核紀錄。

這些是可稽核的描述統計，**不是**受試者與刺激隨機效應的混合模型。

## 資料與規格

- `spec/FARHP_Research_Plan_Spec_v0.7.schema.json`
- `spec/FARHP_Session_Checkpoint_Spec_v0.7.schema.json`
- `spec/FARHP_MultiStimulus_Study_Spec_v0.7.schema.json`
- `spec/FARHP_Group_Analysis_Spec_v0.7.schema.json`
- `examples/deployment_v0.7/`：計畫、檢查點、單人研究與群體分析範例。

## 測試

```bash
node --check app.js
node tests/selftest.cjs
python tests/browser_test.py
python tests/validate_examples.py
```

最終結果：

- Node：36 組測試通過；
- Chromium：部署流程端到端測試通過；
- 控制台錯誤：0；
- JSON Schema：8 份範例全部通過。

受測沙盒禁止瀏覽器直接導航至 `file://` 或本機 HTTP 來源，因此 Chromium 自動測試以嵌入頁面與可替換儲存後端驗證 UI、研究邏輯及檢查點流程；正式使用時仍建議以 `python -m http.server 8000` 開啟，以取得 Web Crypto SHA-256 與較一致的瀏覽器行為。

## 研究邊界

此網站仍是離線聲學與知覺研究 MVP，不是：

- 真人級自然語音 TTS；
- IRB／研究倫理審查替代品；
- 伺服器端受試者管理或多人同步平台；
- 防竄改的密碼學預註冊服務；
- 正式階層貝葉斯或混合效應統計套件；
- FARHP 人類知覺效果已成立的證明。

匿名受試者欄位不得輸入姓名、Email、電話或其他可識別資料。
