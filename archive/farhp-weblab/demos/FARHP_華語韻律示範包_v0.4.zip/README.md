# FARHP v0.4 華語韻律示範

| 檔名 | 文字 | 主要測試 |
|---|---|---|
| `nihao` | 你好 | 三聲變調 |
| `nihaoma` | 你好嗎 | 三聲變調、輕聲、疑問句 |
| `wohenhao` | 我很好 | 連續三聲局部實現 |
| `mamahao` | 媽媽好 | 輕聲 |
| `yigebuhaoma` | 一個不好嗎 | 一變調、疑問句 |
| `yitianbuqu` | 一天不去 | 一／不變調 |
| `grouped` | 我很好｜你呢 | 韻律組邊界、停頓、變調阻斷 |

每個項目包含 WAV 與對應 JSON。JSON 使用：

```text
spec/FARHP_Mandarin_Utterance_Spec_v0.4.schema.json
```
