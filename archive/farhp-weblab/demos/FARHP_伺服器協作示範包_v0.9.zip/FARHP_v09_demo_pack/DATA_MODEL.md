# FARHP v0.9 資料模型

## 實體

- `users`：工作人員帳號與角色。
- `research_plans`：具 revision 的計畫；鎖定後不再改寫。
- `preregistration_archives`：每個鎖定計畫最多一份伺服器封存。
- `invites`：匿名參與代碼、期限與使用次數。
- `study_sessions`：同意、檢查點與完成 study JSON。
- `audit_events`：計畫與工作階段的 SHA-256 前向事件鏈。

## 相容性策略

v0.9 不重寫 v0.8 的研究資料本體：

$$
\text{Server Resource v0.9}
=
\text{Identity／Role／Lifecycle}
+
\text{WebLab Payload v0.8}.
$$

因此計畫、檢查點與完成研究仍可回到離線 WebLab 驗證；伺服器只增加版本、權限、持久化與協作狀態。

## 不可變性

計畫鎖定後：

- `payload_json` 只保留鎖定版本；
- `fingerprint_value` 為計畫核心物件的 SHA-256；
- 新修改必須建立新 revision，而非覆寫；
- 封存紀錄以 `plan_id` 唯一限制避免重複改寫。
