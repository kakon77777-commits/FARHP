# FARHP WebLab MVP v0.9 測試報告

日期：2026-07-31

## 測試範圍

v0.9 的驗證分為五層：

1. FastAPI／SQLite API 與角色權限；
2. 計畫鎖定、封存、邀請、同意、檢查點及完成資料；
3. 伺服器 SHA-256 事件鏈與去識別讀取；
4. Chromium 儀表板互動與視覺渲染；
5. v0.8／v0.9 JSON Schema 相容性及實際 Uvicorn 啟動。

## 結果

```text
16 passed
```

測試包括：

- 健康檢查與 Demo 使用者初始化；
- 正確／錯誤登入；
- principal investigator、data collector、analyst 角色限制；
- v0.8 計畫匯入；
- 伺服器端 SHA-256 重新鎖定；
- 鎖定後不可再次改寫；
- 封存冪等性與封存讀取；
- 未鎖定計畫不得建立邀請；
- 電子同意與資格確認必填；
- 受試者 session token 驗證；
- v0.8 輕量檢查點保存與讀回；
- v0.8 study JSON 完成提交；
- 計畫指紋不一致時拒絕完成資料；
- 分析者取得研究專用假名；
- 計畫與工作階段事件鏈驗證；
- Chromium 儀表板登入、計畫匯入、鎖定、封存與邀請操作。

## Schema 驗證

共 8 組 Schema／範例配對通過：

- Server Plan Resource v0.9：草稿、鎖定計畫；
- Server Invite v0.9：去除可重用邀請碼的示範輸出；
- Server Session Resource v0.9：分析者去識別視圖；
- Server Archive v0.9：完整封存物件；
- WebLab Research Plan v0.8；
- WebLab Session Checkpoint v0.8；
- WebLab Multi-Stimulus Study v0.8。

## 實際伺服器啟動

Uvicorn 實際啟動測試：

| 指標 | 結果 |
|---|---:|
| `/api/health` | PASS |
| 版本 | `0.9.0` |
| Demo 使用者 | 3 |
| OpenAPI 路徑 | 19 |
| Dashboard 回應 | PASS |
| Python compileall | PASS |
| Node 語法檢查 | 3／3 PASS |

## 瀏覽器限制說明

執行環境的 Chromium 管理政策會阻擋直接連線到本機測試埠，因此瀏覽器 UI 測試採用 Playwright 路由模擬 API；真實 HTTP API 則由 TestClient 與獨立 Uvicorn／curl 測試覆蓋。兩層分開驗證，沒有把模擬 UI 測試冒充成完整網路端到端測試。

## 尚未驗證

- 公開網域與 HTTPS 反向代理；
- PostgreSQL 高併發與資料庫遷移；
- OIDC／SSO；
- 多程序寫入競爭；
- 正式備份／還原演練；
- 真實受試者研究與倫理程序；
- 外部可信時間戳或第三方預註冊平台。
