# FARHP Research Server v0.9 API 摘要

## 工作人員認證

```http
POST /api/auth/login
Authorization: Bearer <token>
```

角色：

- `principal_investigator`：匯入／鎖定／封存計畫、建立邀請、檢視原始資料與分析。
- `data_collector`：檢視計畫、建立邀請、檢視工作階段。
- `analyst`：唯讀計畫、去識別工作階段與分析摘要。

## 計畫

- `POST /api/plans`：匯入 v0.8 計畫，建立伺服器草稿 revision。
- `GET /api/plans`：列出計畫。
- `POST /api/plans/{id}/lock`：重新計算 SHA-256 指紋並鎖定。
- `POST /api/plans/{id}/archive`：建立資料庫封存紀錄。
- `POST /api/plans/{id}/invites`：建立匿名參與連結。
- `GET /api/plans/{id}/audit`：驗證計畫事件鏈。

## 受試者

- `GET /api/invites/{code}/public`：公開計畫與同意摘要。
- `POST /api/invites/{code}/sessions`：完成資格與同意，取得匿名工作階段權杖。
- `GET /api/participant/sessions/{id}`：讀取計畫與伺服器檢查點。
- `PUT /api/participant/sessions/{id}/checkpoint`：保存 v0.8 輕量檢查點。
- `POST /api/participant/sessions/{id}/complete`：提交完成的 v0.8 study JSON。

受試者端使用 `X-Session-Token`，不使用工作人員 bearer token。

## 分析

- `GET /api/sessions`：依角色返回原始或去識別工作階段摘要。
- `GET /api/sessions/{session_id}`：研究者可讀原始資料；分析者取得研究專用假名。
- `GET /api/analysis/summary`：群體正確率、Wilson 區間、二項檢定與刺激／條件摘要。
- `GET /api/sessions/{session_id}/audit`：驗證工作階段事件鏈。

完整 OpenAPI 介面在執行中的 `/docs`。
